const Auth = {
    getToken: function() { return localStorage.getItem('token'); },
    getUser: function() {
        const s = localStorage.getItem('user');
        return s ? JSON.parse(s) : null;
    },
    isLoggedIn: function() { return !!this.getToken(); },
    async login(login, password) {
        const res = await Api.post('/auth/login', { login: login, password: password });
        localStorage.setItem('token', res.token);
        localStorage.setItem('user', JSON.stringify({
            userId: res.userId,
            fullName: res.fullName,
            roleName: res.roleName
        }));
        return res;
    },
    async register(data) {
        return Api.post('/auth/register', {
            login: data.login || data.email,
            password: data.password,
            fullName: data.fullName,
            email: data.email,
            phone: data.phone
        });
    },
    logout: function() {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
    }
};
