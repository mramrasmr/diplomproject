const Api = {
    async request(url, options = {}) {
        const token = localStorage.getItem('token');
        const headers = {
            'Content-Type': 'application/json',
            ...(options.headers || {})
        };
        if (token) headers['Authorization'] = 'Bearer ' + token;

        const res = await fetch(API_BASE + url, { ...options, headers });
        const text = await res.text();
        let data = null;
        try { data = text ? JSON.parse(text) : null; } catch (_) {}

        if (!res.ok) {
            const msg = (data && data.message) || (data && data.title) || 'Ошибка ' + res.status;
            throw new Error(msg);
        }
        return data;
    },
    get: function(url) { return this.request(url); },
    post: function(url, body) { return this.request(url, { method: 'POST', body: JSON.stringify(body) }); },
    put: function(url, body) { return this.request(url, { method: 'PUT', body: JSON.stringify(body) }); },
    delete: function(url) { return this.request(url, { method: 'DELETE' }); }
};
