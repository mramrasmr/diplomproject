document.addEventListener('DOMContentLoaded', function() {
    if (typeof Cart !== 'undefined') Cart.init();

    var profileBtn = document.getElementById('headerProfileBtn');
    var cartBtn = document.getElementById('headerCartBtn');

    if (profileBtn) {
        var u = typeof Auth !== 'undefined' && Auth.getUser();
        if (u) {
            profileBtn.innerHTML = '<i class="fas fa-user"></i><span>Профиль</span>';
            profileBtn.onclick = function(e) { e.preventDefault(); e.stopPropagation(); location.href = 'orders.html'; };
        } else {
            profileBtn.innerHTML = '<i class="fas fa-user"></i><span>Войти</span>';
            profileBtn.onclick = function(e) { e.preventDefault(); e.stopPropagation(); location.href = 'login.html'; };
        }
    }
    if (cartBtn) {
        cartBtn.onclick = function(e) { e.preventDefault(); e.stopPropagation(); location.href = 'cart.html'; };
    }
});
