const Cart = {
    STORAGE_KEY: 'stroymarket_cart',

    get() {
        try {
            const s = localStorage.getItem(this.STORAGE_KEY);
            return s ? JSON.parse(s) : [];
        } catch { return []; }
    },

    set(items) {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(items));
        this._updateUI();
    },

    add(product, quantity = 1) {
        const items = this.get();
        const i = items.findIndex(x => x.productId === product.productId);
        if (i >= 0) items[i].quantity += quantity;
        else items.push({
            productId: product.productId,
            name: product.name,
            price: product.price,
            categoryName: product.categoryName || '',
            quantity: quantity
        });
        this.set(items);
    },

    update(productId, quantity) {
        const items = this.get();
        const i = items.findIndex(x => x.productId === productId);
        if (i < 0) return;
        if (quantity <= 0) items.splice(i, 1);
        else items[i].quantity = quantity;
        this.set(items);
    },

    remove(productId) {
        this.update(productId, 0);
    },

    clear() { this.set([]); },

    count() {
        return this.get().reduce((s, x) => s + x.quantity, 0);
    },

    total() {
        return this.get().reduce((s, x) => s + x.price * x.quantity, 0);
    },

    _updateUI() {
        const n = this.count();
        document.querySelectorAll('.carzina-count').forEach(el => el.textContent = n);
    },

    init() { this._updateUI(); }
};
