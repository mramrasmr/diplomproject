using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StroymarketAPI.Models;

[Table("order_items", Schema = "stroy_market")]
public class OrderItem
{
    [Key]
    [Column("order_item_id")]
    public int OrderItemId { get; set; }

    [Column("order_id")]
    public int OrderId { get; set; }

    public Order Order { get; set; } = null!;

    [Column("product_id")]
    public int? ProductId { get; set; }

    public Product? Product { get; set; }

    [Column("service_id")]
    public int? ServiceId { get; set; }

    public Service? Service { get; set; }

    [Column("quantity")]
    public int Quantity { get; set; }

    [Column("price", TypeName = "numeric(12,2)")]
    public decimal Price { get; set; }
}

