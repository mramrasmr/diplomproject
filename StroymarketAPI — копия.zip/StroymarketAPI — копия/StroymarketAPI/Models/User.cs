﻿using System.ComponentModel.DataAnnotations.Schema;

namespace StroymarketAPI.Models;

[Table("users", Schema = "stroy_market")]
public class User
{
    [Column("user_id")]  // ← ключевая строка!
    public int UserId { get; set; }

    [Column("login")]
    public string Login { get; set; } = string.Empty;

    [Column("password_hash")]
    public string PasswordHash { get; set; } = string.Empty;

    [Column("full_name")]
    public string FullName { get; set; } = string.Empty;

    [Column("email")]
    public string? Email { get; set; }

    [Column("phone")]
    public string? Phone { get; set; }

    [Column("role_id")]
    public int RoleId { get; set; }

    public Role Role { get; set; } = null!;
}