using System.ComponentModel.DataAnnotations.Schema;

namespace StroymarketAPI.Models;

[Table("service_promotions", Schema = "stroy_market")]
public class ServicePromotion
{
    [Column("service_id")]
    public int ServiceId { get; set; }

    public Service Service { get; set; } = null!;

    [Column("promotion_id")]
    public int PromotionId { get; set; }

    public Promotion Promotion { get; set; } = null!;
}

