using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace StroymarketAPI.Models;

[Table("services", Schema = "stroy_market")]
public class Service
{
    [Key]
    [Column("service_id")]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int ServiceId { get; set; }

    [Required]
    [MaxLength(100)]
    [Column("name")]
    public string Name { get; set; } = string.Empty;

    [Column("description")]
    public string? Description { get; set; }

    [Column("price", TypeName = "numeric(12,2)")]
    public decimal Price { get; set; }

    [Column("category_id")]
    public int? CategoryId { get; set; }

    public Category? Category { get; set; }

    [JsonIgnore]
    public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();

    [JsonIgnore]
    public ICollection<ServicePromotion> ServicePromotions { get; set; } = new List<ServicePromotion>();
}

