using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace StroymarketAPI.Models;

[Table("orders", Schema = "stroy_market")]
public class Order
{
    [Key]
    [Column("order_id")]
    public int OrderId { get; set; }

    [Column("client_id")]
    public int? ClientId { get; set; }

    public User? Client { get; set; }

    [Column("order_date")]
    public DateTime OrderDate { get; set; }

    [Required]
    [MaxLength(50)]
    [Column("status")]
    public string Status { get; set; } = string.Empty;

    [Column("total_amount", TypeName = "numeric(12,2)")]
    public decimal TotalAmount { get; set; }

    [MaxLength(20)]
    [Column("delivery_type")]
    public string? DeliveryType { get; set; }

    [MaxLength(500)]
    [Column("delivery_address")]
    public string? DeliveryAddress { get; set; }

    [MaxLength(200)]
    [Column("client_name")]
    public string? ClientName { get; set; }

    [MaxLength(50)]
    [Column("client_phone")]
    public string? ClientPhone { get; set; }

    [Column("is_archived")]
    public bool IsArchived { get; set; }

    [JsonIgnore]
    public ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();
}

