using System.ComponentModel.DataAnnotations.Schema;

namespace StroymarketAPI.Models;

[Table("product_promotions", Schema = "stroy_market")]
public class ProductPromotion
{
    [Column("product_id")]
    public int ProductId { get; set; }

    public Product Product { get; set; } = null!;

    [Column("promotion_id")]
    public int PromotionId { get; set; }

    public Promotion Promotion { get; set; } = null!;
}

