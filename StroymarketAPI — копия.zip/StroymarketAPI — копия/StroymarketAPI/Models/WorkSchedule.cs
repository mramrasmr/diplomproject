using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StroymarketAPI.Models;

[Table("work_schedules", Schema = "stroy_market")]
public class WorkSchedule
{
    [Key]
    [Column("schedule_id")]
    public int ScheduleId { get; set; }

    [Column("employee_id")]
    public int EmployeeId { get; set; }

    public User Employee { get; set; } = null!;

    [Column("work_date")]
    public DateTime WorkDate { get; set; }

    [Column("start_time")]
    public TimeSpan StartTime { get; set; }

    [Column("end_time")]
    public TimeSpan EndTime { get; set; }
}

