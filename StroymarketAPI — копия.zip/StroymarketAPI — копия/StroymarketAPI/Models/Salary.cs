using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StroymarketAPI.Models;

[Table("salaries", Schema = "stroy_market")]
public class Salary
{
    [Key]
    [Column("salary_id")]
    public int SalaryId { get; set; }

    [Column("employee_id")]
    public int EmployeeId { get; set; }

    public User Employee { get; set; } = null!;

    [Column("base_amount", TypeName = "numeric(12,2)")]
    public decimal BaseAmount { get; set; }

    [Column("bonus", TypeName = "numeric(12,2)")]
    public decimal Bonus { get; set; }

    [Column("penalty", TypeName = "numeric(12,2)")]
    public decimal Penalty { get; set; }

    [Column("period")]
    public DateTime Period { get; set; }
}

