﻿using StroymarketAPI.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

[Table("roles", Schema = "stroy_market")]
public class Role
{
    [Column("role_id")] // ← если в БД тоже role_id (а не RoleId)
    public int RoleId { get; set; }

    [Column("role_name")]
    public string RoleName { get; set; } = string.Empty;

    [JsonIgnore]
    public ICollection<User> Users { get; set; } = new List<User>();
}