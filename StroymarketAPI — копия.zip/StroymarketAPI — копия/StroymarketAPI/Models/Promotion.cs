using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace StroymarketAPI.Models;

[Table("promotions", Schema = "stroy_market")]
public class Promotion
{
    [Key]
    [Column("promotion_id")]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int PromotionId { get; set; }

    [Required]
    [MaxLength(100)]
    [Column("title")]
    public string Title { get; set; } = string.Empty;

    [Column("discount_value", TypeName = "numeric(5,2)")]
    public decimal DiscountValue { get; set; }

    [Column("start_date")]
    public DateTime StartDate { get; set; }

    [Column("end_date")]
    public DateTime EndDate { get; set; }

    [Required]
    [MaxLength(50)]
    [Column("status")]
    public string Status { get; set; } = string.Empty;

    [JsonIgnore]
    public ICollection<PromoCode> PromoCodes { get; set; } = new List<PromoCode>();

    [JsonIgnore]
    public ICollection<ProductPromotion> ProductPromotions { get; set; } = new List<ProductPromotion>();

    [JsonIgnore]
    public ICollection<ServicePromotion> ServicePromotions { get; set; } = new List<ServicePromotion>();
}

