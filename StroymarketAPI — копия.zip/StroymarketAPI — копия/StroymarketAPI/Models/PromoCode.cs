using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace StroymarketAPI.Models;

[Table("promo_codes", Schema = "stroy_market")]
public class PromoCode
{
    [Key]
    [Column("promo_code_id")]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int PromoCodeId { get; set; }

    [Required]
    [MaxLength(50)]
    [Column("code")]
    public string Code { get; set; } = string.Empty;

    [Column("promotion_id")]
    public int? PromotionId { get; set; }

    public Promotion? Promotion { get; set; }

    [Column("discount_value", TypeName = "numeric(5,2)")]
    public decimal? DiscountValue { get; set; }

    [Column("is_active")]
    public bool IsActive { get; set; } = true;
}

