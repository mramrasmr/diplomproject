using System.Text.Json.Serialization;

namespace StroymarketAPI.Models;

public class LoginResponse
{
    public string Token { get; set; } = string.Empty;
    public int UserId { get; set; }
    public string FullName { get; set; } = string.Empty;
    [JsonPropertyName("roleName")]
    public string RoleName { get; set; } = string.Empty;
}