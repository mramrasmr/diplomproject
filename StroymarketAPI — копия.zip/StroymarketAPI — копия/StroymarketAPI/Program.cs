using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Npgsql;
using StroymarketAPI.Data;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// ✅ Сначала получаем строку подключения
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
                       ?? throw new InvalidOperationException("Строка подключения 'DefaultConnection' не найдена.");

// ✅ Проверка подключения (опционально, но полезно при отладке)
try
{
    using var conn = new NpgsqlConnection(connectionString);
    conn.Open();
    Console.WriteLine("✅ Подключение к PostgreSQL успешно!");
}
catch (Exception ex)
{
    Console.WriteLine($"❌ Ошибка подключения: {ex.Message}");
    throw; // или просто return, если хочешь продолжить без БД (не рекомендуется)
}

// ✅ Теперь добавляем DbContext — уже после объявления connectionString
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(connectionString));

// JWT аутентификация
var jwtSection = builder.Configuration.GetSection("Jwt");
var jwtKey = jwtSection.GetValue<string>("Key") ?? throw new InvalidOperationException("Jwt:Key не задан");
var jwtIssuer = jwtSection.GetValue<string>("Issuer");
var jwtAudience = jwtSection.GetValue<string>("Audience");

builder.Services
    .AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    })
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtIssuer,
            ValidAudience = jwtAudience,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
            RoleClaimType = "role"
        };
        options.Events = new Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerEvents
        {
            OnAuthenticationFailed = ctx =>
            {
                var hasHeader = ctx.Request.Headers.ContainsKey("Authorization");
                Console.WriteLine($"[JWT] 401: Authorization header present = {hasHeader}. Error: {ctx.Exception?.Message}");
                return Task.CompletedTask;
            },
            OnChallenge = ctx =>
            {
                var hasHeader = ctx.Request.Headers.ContainsKey("Authorization");
                Console.WriteLine($"[JWT] Challenge: Authorization header present = {hasHeader}");
                return Task.CompletedTask;
            }
        };
    });

// Добавляем остальные сервисы
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();
app.UseCors();

// Статические файлы: ImagePublic доступен по /ImagePublic
var imagePublicPath = Path.Combine(app.Environment.ContentRootPath, "ImagePublic");
if (!Directory.Exists(imagePublicPath))
    Directory.CreateDirectory(imagePublicPath);
app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new Microsoft.Extensions.FileProviders.PhysicalFileProvider(imagePublicPath),
    RequestPath = "/ImagePublic"
});

// Конфигурация HTTP-конвейера
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "v1");
        options.RoutePrefix = "swagger"; // Swagger будет доступен по корню: /swagger
    });
}

// В Development не делаем редирект HTTP→HTTPS, иначе клиент при редиректе теряет заголовок Authorization
if (!app.Environment.IsDevelopment())
    app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

Console.WriteLine("🚀 API запущен. Ждём запросы...");
app.Run();