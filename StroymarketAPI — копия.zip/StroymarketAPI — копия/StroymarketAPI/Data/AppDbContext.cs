using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Models;

namespace StroymarketAPI.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Role> Roles => Set<Role>();

    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();
    public DbSet<Promotion> Promotions => Set<Promotion>();
    public DbSet<PromoCode> PromoCodes => Set<PromoCode>();
    public DbSet<Service> Services => Set<Service>();
    public DbSet<ProductPromotion> ProductPromotions => Set<ProductPromotion>();
    public DbSet<ServicePromotion> ServicePromotions => Set<ServicePromotion>();
    public DbSet<Salary> Salaries => Set<Salary>();
    public DbSet<WorkSchedule> WorkSchedules => Set<WorkSchedule>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Схема по умолчанию
        modelBuilder.HasDefaultSchema("stroy_market");

        // Пользователи и роли
        modelBuilder.Entity<User>()
            .HasOne(u => u.Role)
            .WithMany(r => r.Users)
            .HasForeignKey(u => u.RoleId);

        // Товары и категории
        modelBuilder.Entity<Product>()
            .HasOne(p => p.Category)
            .WithMany(c => c.Products)
            .HasForeignKey(p => p.CategoryId);

        // Заказы и клиенты
        modelBuilder.Entity<Order>()
            .HasOne(o => o.Client)
            .WithMany()
            .HasForeignKey(o => o.ClientId);

        // Позиции заказа
        modelBuilder.Entity<OrderItem>()
            .HasOne(oi => oi.Order)
            .WithMany(o => o.Items)
            .HasForeignKey(oi => oi.OrderId);

        modelBuilder.Entity<OrderItem>()
            .HasOne(oi => oi.Product)
            .WithMany(p => p.OrderItems)
            .HasForeignKey(oi => oi.ProductId);

        modelBuilder.Entity<OrderItem>()
            .HasOne(oi => oi.Service)
            .WithMany(s => s.OrderItems)
            .HasForeignKey(oi => oi.ServiceId);

        // Промо-товары
        modelBuilder.Entity<ProductPromotion>()
            .HasKey(pp => new { pp.ProductId, pp.PromotionId });

        modelBuilder.Entity<ProductPromotion>()
            .HasOne(pp => pp.Product)
            .WithMany(p => p.ProductPromotions)
            .HasForeignKey(pp => pp.ProductId);

        modelBuilder.Entity<ProductPromotion>()
            .HasOne(pp => pp.Promotion)
            .WithMany(p => p.ProductPromotions)
            .HasForeignKey(pp => pp.PromotionId);

        // Промо-услуги
        modelBuilder.Entity<ServicePromotion>()
            .HasKey(sp => new { sp.ServiceId, sp.PromotionId });

        modelBuilder.Entity<ServicePromotion>()
            .HasOne(sp => sp.Service)
            .WithMany(s => s.ServicePromotions)
            .HasForeignKey(sp => sp.ServiceId);

        modelBuilder.Entity<ServicePromotion>()
            .HasOne(sp => sp.Promotion)
            .WithMany(p => p.ServicePromotions)
            .HasForeignKey(sp => sp.PromotionId);

        // Промокоды
        modelBuilder.Entity<PromoCode>()
            .HasOne(pc => pc.Promotion)
            .WithMany(p => p.PromoCodes)
            .HasForeignKey(pc => pc.PromotionId);

        // Услуги и категории
        modelBuilder.Entity<Service>()
            .HasOne(s => s.Category)
            .WithMany()
            .HasForeignKey(s => s.CategoryId);

        // Графики и зарплаты
        modelBuilder.Entity<WorkSchedule>()
            .HasOne(ws => ws.Employee)
            .WithMany()
            .HasForeignKey(ws => ws.EmployeeId);

        modelBuilder.Entity<WorkSchedule>()
            .Property(ws => ws.WorkDate)
            .HasColumnType("date");

        modelBuilder.Entity<WorkSchedule>()
            .Property(ws => ws.StartTime)
            .HasColumnType("time");

        modelBuilder.Entity<WorkSchedule>()
            .Property(ws => ws.EndTime)
            .HasColumnType("time");

        modelBuilder.Entity<Salary>()
            .HasOne(s => s.Employee)
            .WithMany()
            .HasForeignKey(s => s.EmployeeId);

        base.OnModelCreating(modelBuilder);
    }
}