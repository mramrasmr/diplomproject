using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;
using StroymarketAPI.Dtos;
using StroymarketAPI.Models;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UsersController : ControllerBase
{
    private readonly AppDbContext _context;

    public UsersController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet("roles")]
    public async Task<ActionResult<IEnumerable<RoleDto>>> GetRoles()
    {
        var roles = await _context.Roles
            .Where(r => r.RoleName == "Сотрудник" || r.RoleName == "Директор")
            .OrderBy(r => r.RoleId)
            .Select(r => new RoleDto { RoleId = r.RoleId, RoleName = r.RoleName })
            .ToListAsync();
        return Ok(roles);
    }

    [HttpGet("staff")]
    public async Task<ActionResult<IEnumerable<UserDto>>> GetStaff(
        [FromQuery] string? search,
        [FromQuery] int? roleId)
    {
        var query = _context.Users
            .Include(u => u.Role)
            .Where(u => u.Role.RoleName == "Сотрудник" || u.Role.RoleName == "Директор")
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim().ToLower();
            query = query.Where(u =>
                (u.FullName != null && u.FullName.ToLower().Contains(s)) ||
                (u.Email != null && u.Email.ToLower().Contains(s)) ||
                (u.Phone != null && u.Phone.Contains(s)) ||
                (u.Login != null && u.Login.ToLower().Contains(s)));
        }

        if (roleId.HasValue)
        {
            query = query.Where(u => u.RoleId == roleId.Value);
        }

        var staff = await query
            .OrderBy(u => u.FullName)
            .Select(u => new UserDto
            {
                UserId = u.UserId,
                Login = u.Login,
                FullName = u.FullName,
                RoleName = u.Role.RoleName,
                RoleId = u.RoleId,
                Email = u.Email,
                Phone = u.Phone
            })
            .ToListAsync();

        return Ok(staff);
    }

    [HttpPost("staff")]
    public async Task<ActionResult<UserDto>> CreateStaff([FromBody] UserCreateUpdateDto dto)
    {
        if (string.IsNullOrWhiteSpace(dto.Password))
        {
            return BadRequest(new { message = "Пароль обязателен при создании пользователя." });
        }

        var user = new User
        {
            Login = dto.Login,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
            FullName = dto.FullName,
            Email = dto.Email,
            Phone = dto.Phone,
            RoleId = dto.RoleId
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetStaff), null, new UserDto
        {
            UserId = user.UserId,
            FullName = user.FullName,
            RoleName = (await _context.Roles.FindAsync(user.RoleId))?.RoleName ?? string.Empty,
            Email = user.Email,
            Phone = user.Phone
        });
    }

    [HttpPut("staff/{id:int}")]
    public async Task<IActionResult> UpdateStaff(int id, [FromBody] UserCreateUpdateDto dto)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            return NotFound();
        }

        user.Login = dto.Login;
        user.FullName = dto.FullName;
        user.Email = dto.Email;
        user.Phone = dto.Phone;
        user.RoleId = dto.RoleId;

        if (!string.IsNullOrWhiteSpace(dto.Password))
        {
            user.PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password);
        }

        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("staff/{id:int}")]
    public async Task<IActionResult> DeleteStaff(int id)
    {
        var user = await _context.Users.FindAsync(id);
        if (user == null)
        {
            return NotFound();
        }

        _context.Users.Remove(user);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}

