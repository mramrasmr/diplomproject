using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;
using StroymarketAPI.Dtos;
using StroymarketAPI.Models;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SalariesController : ControllerBase
{
    private readonly AppDbContext _context;

    public SalariesController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<SalaryDto>>> GetSalaries([FromQuery] int? employeeId = null)
    {
        var query = _context.Salaries.Include(s => s.Employee).AsQueryable();
        if (employeeId.HasValue)
            query = query.Where(s => s.EmployeeId == employeeId.Value);
        var list = await query
            .OrderByDescending(s => s.Period)
            .Select(s => new SalaryDto
            {
                SalaryId = s.SalaryId,
                EmployeeId = s.EmployeeId,
                EmployeeName = s.Employee.FullName,
                BaseAmount = s.BaseAmount,
                Bonus = s.Bonus,
                Penalty = s.Penalty,
                Period = s.Period
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpPost]
    public async Task<ActionResult<SalaryDto>> CreateSalary([FromBody] SalaryCreateUpdateDto dto)
    {
        var employeeExists = await _context.Users.AnyAsync(u => u.UserId == dto.EmployeeId);
        if (!employeeExists)
            return BadRequest(new { message = "Сотрудник не найден." });

        var salary = new Salary
        {
            EmployeeId = dto.EmployeeId,
            BaseAmount = dto.BaseAmount,
            Bonus = dto.Bonus,
            Penalty = dto.Penalty,
            Period = dto.Period
        };

        _context.Salaries.Add(salary);
        await _context.SaveChangesAsync();

        var created = await _context.Salaries
            .Include(s => s.Employee)
            .FirstAsync(s => s.SalaryId == salary.SalaryId);

        var result = new SalaryDto
        {
            SalaryId = created.SalaryId,
            EmployeeId = created.EmployeeId,
            EmployeeName = created.Employee.FullName,
            BaseAmount = created.BaseAmount,
            Bonus = created.Bonus,
            Penalty = created.Penalty,
            Period = created.Period
        };
        return Created($"/api/salaries/{created.SalaryId}", result);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> UpdateSalary(int id, [FromBody] SalaryCreateUpdateDto dto)
    {
        var salary = await _context.Salaries.FindAsync(id);
        if (salary == null)
            return NotFound();

        var employeeExists = await _context.Users.AnyAsync(u => u.UserId == dto.EmployeeId);
        if (!employeeExists)
            return BadRequest(new { message = "Сотрудник не найден." });

        salary.EmployeeId = dto.EmployeeId;
        salary.BaseAmount = dto.BaseAmount;
        salary.Bonus = dto.Bonus;
        salary.Penalty = dto.Penalty;
        salary.Period = dto.Period;

        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteSalary(int id)
    {
        var salary = await _context.Salaries.FindAsync(id);
        if (salary == null)
            return NotFound();

        _context.Salaries.Remove(salary);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}

