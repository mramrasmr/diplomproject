using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;
using StroymarketAPI.Models;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PromotionsController : ControllerBase
{
    private readonly AppDbContext _context;

    public PromotionsController(AppDbContext context)
    {
        _context = context;
    }

    private static DateTime ToUtc(DateTime dt) => dt.Kind == DateTimeKind.Utc ? dt : DateTime.SpecifyKind(dt.Date, DateTimeKind.Utc);

    [HttpGet]
    public async Task<ActionResult<IEnumerable<PromotionDto>>> GetPromotions([FromQuery] string? status)
    {
        var query = _context.Promotions.AsQueryable();
        if (!string.IsNullOrWhiteSpace(status))
            query = query.Where(p => p.Status == status);

        var list = await query
            .OrderByDescending(p => p.StartDate)
            .Select(p => new PromotionDto
            {
                PromotionId = p.PromotionId,
                Title = p.Title,
                DiscountValue = p.DiscountValue,
                StartDate = p.StartDate,
                EndDate = p.EndDate,
                Status = p.Status
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<PromotionDto>> GetPromotion(int id)
    {
        var p = await _context.Promotions.FindAsync(id);
        if (p == null) return NotFound();

        return Ok(new PromotionDto
        {
            PromotionId = p.PromotionId,
            Title = p.Title,
            DiscountValue = p.DiscountValue,
            StartDate = p.StartDate,
            EndDate = p.EndDate,
            Status = p.Status
        });
    }

    [HttpPost]
    public async Task<ActionResult<PromotionDto>> CreatePromotion([FromBody] PromotionCreateUpdateDto dto)
    {
        var p = new Promotion
        {
            Title = dto.Title,
            DiscountValue = dto.DiscountValue,
            StartDate = ToUtc(dto.StartDate),
            EndDate = ToUtc(dto.EndDate),
            Status = dto.Status ?? "активна"
        };
        _context.Promotions.Add(p);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetPromotion), new { id = p.PromotionId }, new PromotionDto
        {
            PromotionId = p.PromotionId,
            Title = p.Title,
            DiscountValue = p.DiscountValue,
            StartDate = p.StartDate,
            EndDate = p.EndDate,
            Status = p.Status
        });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> UpdatePromotion(int id, [FromBody] PromotionCreateUpdateDto dto)
    {
        var p = await _context.Promotions.FindAsync(id);
        if (p == null) return NotFound();

        p.Title = dto.Title;
        p.DiscountValue = dto.DiscountValue;
        p.StartDate = ToUtc(dto.StartDate);
        p.EndDate = ToUtc(dto.EndDate);
        p.Status = dto.Status ?? p.Status;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeletePromotion(int id)
    {
        var p = await _context.Promotions.FindAsync(id);
        if (p == null) return NotFound();

        var relatedPromoCodes = await _context.PromoCodes.Where(pc => pc.PromotionId == id).ToListAsync();
        foreach (var pc in relatedPromoCodes)
            pc.PromotionId = null;

        _context.Promotions.Remove(p);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}

public class PromotionDto
{
    public int PromotionId { get; set; }
    public string Title { get; set; } = string.Empty;
    public decimal DiscountValue { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Status { get; set; } = string.Empty;
}

public class PromotionCreateUpdateDto
{
    public string Title { get; set; } = string.Empty;
    public decimal DiscountValue { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string? Status { get; set; }
}
