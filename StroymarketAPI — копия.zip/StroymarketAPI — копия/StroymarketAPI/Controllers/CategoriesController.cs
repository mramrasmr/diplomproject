using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;
using StroymarketAPI.Dtos;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CategoriesController : ControllerBase
{
    private readonly AppDbContext _context;

    public CategoriesController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<CategoryDto>>> GetCategories()
    {
        var list = await _context.Categories
            .OrderBy(c => c.Name)
            .Select(c => new CategoryDto
            {
                CategoryId = c.CategoryId,
                Name = c.Name
            })
            .ToListAsync();

        return Ok(list);
    }
}

