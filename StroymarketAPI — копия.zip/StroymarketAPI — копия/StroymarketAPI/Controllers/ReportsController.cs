using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ReportsController : ControllerBase
{
    private readonly AppDbContext _context;

    public ReportsController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet("products/csv")]
    public async Task<IActionResult> GetProductsReportCsv()
    {
        var products = await _context.Products
            .Include(p => p.Category)
            .OrderBy(p => p.Name)
            .ToListAsync();

        var sb = new StringBuilder();
        sb.AppendLine("Id;Название;Категория;Цена;Остаток;Статус");

        foreach (var p in products)
        {
            sb.AppendLine($"{p.ProductId};\"{p.Name}\";\"{p.Category?.Name}\";{p.Price};{p.Quantity};\"{p.Status}\"");
        }

        var encoding = new UTF8Encoding(true);
        var bytes = encoding.GetBytes(sb.ToString());
        return File(bytes, "text/csv; charset=utf-8", "products_report.csv");
    }

    [HttpGet("sales/csv")]
    public async Task<IActionResult> GetSalesReportCsv()
    {
        var orders = await _context.Orders
            .Include(o => o.Client)
            .OrderByDescending(o => o.OrderDate)
            .ToListAsync();

        var sb = new StringBuilder();
        sb.AppendLine("Id;Дата;Клиент;Статус;Сумма");

        foreach (var o in orders)
        {
            sb.AppendLine($"{o.OrderId};{o.OrderDate:yyyy-MM-dd HH:mm};\"{o.Client?.FullName}\";\"{o.Status}\";{o.TotalAmount}");
        }

        var encoding = new UTF8Encoding(true);
        var bytes = encoding.GetBytes(sb.ToString());
        return File(bytes, "text/csv; charset=utf-8", "sales_report.csv");
    }
}

