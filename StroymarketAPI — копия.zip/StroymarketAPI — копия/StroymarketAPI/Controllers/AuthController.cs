using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using StroymarketAPI.Data;
using StroymarketAPI.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IConfiguration _configuration;

    public AuthController(AppDbContext context, IConfiguration configuration)
    {
        _context = context;
        _configuration = configuration;
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginRequest request)
    {
        var user = _context.Users
            .Include(u => u.Role) 
            .FirstOrDefault(u => u.Login == request.Login);

        if (user is null)
        {
            return Unauthorized(new { message = "Неверный логин" });
        }

        
        // 2. Проверяем пароль по хэшу в БД (bcrypt)
        
        if (!BCrypt.Net.BCrypt.Verify(request.Password, user.PasswordHash))
        {
            return Unauthorized(new { message = "Неверный логин или пароль" });
        }

        // 3. Формируем JWT-токен
        var jwtSection = _configuration.GetSection("Jwt");
        var key = jwtSection.GetValue<string>("Key")!;
        var issuer = jwtSection.GetValue<string>("Issuer");
        var audience = jwtSection.GetValue<string>("Audience");
        var expiresMinutes = jwtSection.GetValue<int>("ExpiresMinutes", 60);

        // Роль из stroy_market.roles.role_name (если Role не подгружен — по role_id: 3=Директор, 2=Сотрудник)
        var roleName = user.Role?.RoleName
            ?? (user.RoleId == 3 ? "Директор" : user.RoleId == 2 ? "Сотрудник" : "Клиент");

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.UserId.ToString()),
            new Claim(ClaimTypes.Name, user.Login),
            new Claim(ClaimTypes.Role, roleName),
            new Claim("role", roleName)
        };

        var signingKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
        var creds = new SigningCredentials(signingKey, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: issuer,
            audience: audience,
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(expiresMinutes),
            signingCredentials: creds);

        var jwt = new JwtSecurityTokenHandler().WriteToken(token);

        // 4. Формируем ответ
        var response = new LoginResponse
        {
            UserId = user.UserId,
            FullName = user.FullName,
            RoleName = user.Role?.RoleName ?? "Неизвестно",
            Token = jwt
        };

        return Ok(response);
    }

    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request)
    {
        var existing = await _context.Users.FirstOrDefaultAsync(u => u.Login == request.Login || u.Email == request.Email);
        if (existing != null)
        {
            if (existing.Login == request.Login)
                return BadRequest(new { message = "Пользователь с таким логином уже существует." });
            return BadRequest(new { message = "Пользователь с таким email уже зарегистрирован." });
        }

        var clientRole = await _context.Roles.FirstOrDefaultAsync(r => r.RoleName == "Клиент");
        var roleId = clientRole?.RoleId ?? 1;

        var user = new User
        {
            Login = request.Login,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
            FullName = request.FullName,
            Email = request.Email,
            Phone = request.Phone,
            RoleId = roleId
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        return Ok(new { userId = user.UserId, message = "Регистрация успешна. Вы можете войти в систему." });
    }
}

public class RegisterRequest
{
    public string Login { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string FullName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Phone { get; set; }
}