using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;
using StroymarketAPI.Models;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PromoCodesController : ControllerBase
{
    private readonly AppDbContext _context;

    public PromoCodesController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<PromoCodeDto>>> GetPromoCodes(
        [FromQuery] bool? isActive,
        [FromQuery] int? promotionId)
    {
        var query = _context.PromoCodes
            .Include(pc => pc.Promotion)
            .AsQueryable();

        if (isActive.HasValue)
            query = query.Where(pc => pc.IsActive == isActive.Value);
        if (promotionId.HasValue)
            query = query.Where(pc => pc.PromotionId == promotionId.Value);

        var list = await query
            .OrderBy(pc => pc.Code)
            .Select(pc => new PromoCodeDto
            {
                PromoCodeId = pc.PromoCodeId,
                Code = pc.Code,
                PromotionId = pc.PromotionId,
                PromotionTitle = pc.Promotion != null ? pc.Promotion.Title : null,
                DiscountValue = pc.DiscountValue,
                IsActive = pc.IsActive
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpPost("validate")]
    public async Task<IActionResult> ValidatePromoCode([FromBody] ValidatePromoCodeRequest request)
    {
        var pc = await _context.PromoCodes
            .Include(x => x.Promotion)
            .FirstOrDefaultAsync(x => x.Code.ToUpper() == request.Code.ToUpper().Trim());

        if (pc == null)
            return NotFound(new { valid = false, message = "Промокод не найден." });

        if (!pc.IsActive)
            return BadRequest(new { valid = false, message = "Промокод недействителен." });

        var discount = pc.DiscountValue ?? (pc.Promotion != null ? pc.Promotion.DiscountValue : 0);
        return Ok(new { valid = true, discountValue = discount, message = $"Скидка {discount}%" });
    }

    [HttpPost]
    public async Task<ActionResult<PromoCodeDto>> CreatePromoCode([FromBody] PromoCodeCreateUpdateDto dto)
    {
        var existing = await _context.PromoCodes.FirstOrDefaultAsync(pc => pc.Code == dto.Code);
        if (existing != null)
            return BadRequest(new { message = "Промокод с таким кодом уже существует." });

        var pc = new PromoCode
        {
            Code = dto.Code,
            PromotionId = dto.PromotionId == 0 ? null : dto.PromotionId,
            DiscountValue = dto.DiscountValue,
            IsActive = dto.IsActive
        };
        _context.PromoCodes.Add(pc);
        await _context.SaveChangesAsync();

        var promo = pc.PromotionId.HasValue ? await _context.Promotions.FindAsync(pc.PromotionId) : null;
        return CreatedAtAction(nameof(GetPromoCodes), null, new PromoCodeDto
        {
            PromoCodeId = pc.PromoCodeId,
            Code = pc.Code,
            PromotionId = pc.PromotionId,
            PromotionTitle = promo?.Title,
            DiscountValue = pc.DiscountValue,
            IsActive = pc.IsActive
        });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> UpdatePromoCode(int id, [FromBody] PromoCodeCreateUpdateDto dto)
    {
        var pc = await _context.PromoCodes.FindAsync(id);
        if (pc == null) return NotFound();

        var existing = await _context.PromoCodes.FirstOrDefaultAsync(x => x.Code == dto.Code && x.PromoCodeId != id);
        if (existing != null)
            return BadRequest(new { message = "Промокод с таким кодом уже существует." });

        pc.Code = dto.Code;
        pc.PromotionId = dto.PromotionId;
        pc.DiscountValue = dto.DiscountValue;
        pc.IsActive = dto.IsActive;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeletePromoCode(int id)
    {
        var pc = await _context.PromoCodes.FindAsync(id);
        if (pc == null) return NotFound();

        _context.PromoCodes.Remove(pc);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}

public class PromoCodeDto
{
    public int PromoCodeId { get; set; }
    public string Code { get; set; } = string.Empty;
    public int? PromotionId { get; set; }
    public string? PromotionTitle { get; set; }
    public decimal? DiscountValue { get; set; }
    public bool IsActive { get; set; }
}

public class PromoCodeCreateUpdateDto
{
    public string Code { get; set; } = string.Empty;
    public int? PromotionId { get; set; }
    public decimal? DiscountValue { get; set; }
    public bool IsActive { get; set; } = true;
}

public class ValidatePromoCodeRequest
{
    public string Code { get; set; } = string.Empty;
}
