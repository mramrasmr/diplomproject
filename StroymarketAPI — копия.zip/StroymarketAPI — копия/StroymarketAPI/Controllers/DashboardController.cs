using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;
using StroymarketAPI.Dtos;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DashboardController : ControllerBase
{
    private readonly AppDbContext _context;

    public DashboardController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet("summary")]
    public async Task<ActionResult<DashboardSummaryDto>> GetSummary()
    {
        var now = DateTime.UtcNow;
        var today = now.Date;

        var totalRevenue = await _context.Orders.SumAsync(o => o.TotalAmount);
        var productsInStock = await _context.Products.SumAsync(p => p.Quantity);
        var staffCount = await _context.Users
            .Include(u => u.Role)
            .CountAsync(u => u.Role.RoleName == "Сотрудник" || u.Role.RoleName == "Директор");
        var ordersToday = await _context.Orders.CountAsync(o => o.OrderDate.Date == today);

        var lowStockProducts = await _context.Products
            .Where(p => p.Quantity <= 10)
            .OrderBy(p => p.Quantity)
            .Take(5)
            .Select(p => new LowStockProductDto
            {
                ProductId = p.ProductId,
                Name = p.Name,
                Quantity = p.Quantity
            })
            .ToListAsync();

        var dto = new DashboardSummaryDto
        {
            TotalRevenue = totalRevenue,
            ProductsInStock = productsInStock,
            StaffCount = staffCount,
            OrdersToday = ordersToday,
            LowStockProducts = lowStockProducts
        };

        return Ok(dto);
    }
}

