using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;
using StroymarketAPI.Models;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ServicesController : ControllerBase
{
    private readonly AppDbContext _context;

    public ServicesController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<ServiceDto>>> GetServices([FromQuery] int? categoryId)
    {
        var query = _context.Services.Include(s => s.Category).AsQueryable();
        if (categoryId.HasValue && categoryId.Value != 0)
            query = query.Where(s => s.CategoryId == categoryId.Value);

        var list = await query
            .OrderBy(s => s.Name)
            .Select(s => new ServiceDto
            {
                ServiceId = s.ServiceId,
                Name = s.Name,
                Description = s.Description,
                Price = s.Price,
                CategoryId = s.CategoryId,
                CategoryName = s.Category != null ? s.Category.Name : null
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<ServiceDto>> GetService(int id)
    {
        var s = await _context.Services.Include(s => s.Category).FirstOrDefaultAsync(s => s.ServiceId == id);
        if (s == null) return NotFound();

        return Ok(new ServiceDto
        {
            ServiceId = s.ServiceId,
            Name = s.Name,
            Description = s.Description,
            Price = s.Price,
            CategoryId = s.CategoryId,
            CategoryName = s.Category?.Name
        });
    }

    [HttpPost]
    public async Task<ActionResult<ServiceDto>> CreateService([FromBody] ServiceCreateUpdateDto dto)
    {
        var s = new Service
        {
            Name = dto.Name,
            Description = dto.Description,
            Price = dto.Price,
            CategoryId = dto.CategoryId == 0 ? null : dto.CategoryId
        };
        _context.Services.Add(s);
        await _context.SaveChangesAsync();

        var cat = s.CategoryId.HasValue ? await _context.Categories.FindAsync(s.CategoryId) : null;
        return CreatedAtAction(nameof(GetService), new { id = s.ServiceId }, new ServiceDto
        {
            ServiceId = s.ServiceId,
            Name = s.Name,
            Description = s.Description,
            Price = s.Price,
            CategoryId = s.CategoryId,
            CategoryName = cat?.Name
        });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> UpdateService(int id, [FromBody] ServiceCreateUpdateDto dto)
    {
        var s = await _context.Services.FindAsync(id);
        if (s == null) return NotFound();

        s.Name = dto.Name;
        s.Description = dto.Description;
        s.Price = dto.Price;
        s.CategoryId = dto.CategoryId == 0 ? null : dto.CategoryId;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteService(int id)
    {
        var s = await _context.Services.FindAsync(id);
        if (s == null) return NotFound();

        _context.Services.Remove(s);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}

public class ServiceDto
{
    public int ServiceId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public decimal Price { get; set; }
    public int? CategoryId { get; set; }
    public string? CategoryName { get; set; }
}

public class ServiceCreateUpdateDto
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public decimal Price { get; set; }
    public int? CategoryId { get; set; }
}
