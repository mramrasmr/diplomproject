using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;
using StroymarketAPI.Models;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class WorkSchedulesController : ControllerBase
{
    private readonly AppDbContext _context;

    public WorkSchedulesController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<WorkScheduleDto>>> GetSchedules(
        [FromQuery] int? employeeId,
        [FromQuery] DateTime? from,
        [FromQuery] DateTime? to)
    {
        var query = _context.WorkSchedules
            .Include(ws => ws.Employee)
            .AsQueryable();

        if (employeeId.HasValue)
            query = query.Where(ws => ws.EmployeeId == employeeId.Value);
        if (from.HasValue)
            query = query.Where(ws => ws.WorkDate >= from.Value.Date);
        if (to.HasValue)
            query = query.Where(ws => ws.WorkDate <= to.Value.Date);

        var list = await query
            .OrderBy(ws => ws.WorkDate)
            .ThenBy(ws => ws.StartTime)
            .Select(ws => new WorkScheduleDto
            {
                ScheduleId = ws.ScheduleId,
                EmployeeId = ws.EmployeeId,
                EmployeeName = ws.Employee != null ? ws.Employee.FullName : null,
                WorkDate = ws.WorkDate,
                StartTime = ws.StartTime,
                EndTime = ws.EndTime
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpPost]
    public async Task<ActionResult<WorkScheduleDto>> CreateSchedule([FromBody] WorkScheduleCreateUpdateDto dto)
    {
        var ws = new WorkSchedule
        {
            EmployeeId = dto.EmployeeId,
            WorkDate = dto.WorkDate,
            StartTime = dto.StartTime,
            EndTime = dto.EndTime
        };
        _context.WorkSchedules.Add(ws);
        await _context.SaveChangesAsync();

        var emp = await _context.Users.FindAsync(ws.EmployeeId);
        return CreatedAtAction(nameof(GetSchedules), null, new WorkScheduleDto
        {
            ScheduleId = ws.ScheduleId,
            EmployeeId = ws.EmployeeId,
            EmployeeName = emp?.FullName,
            WorkDate = ws.WorkDate,
            StartTime = ws.StartTime,
            EndTime = ws.EndTime
        });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> UpdateSchedule(int id, [FromBody] WorkScheduleCreateUpdateDto dto)
    {
        var ws = await _context.WorkSchedules.FindAsync(id);
        if (ws == null) return NotFound();

        ws.EmployeeId = dto.EmployeeId;
        ws.WorkDate = dto.WorkDate;
        ws.StartTime = dto.StartTime;
        ws.EndTime = dto.EndTime;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteSchedule(int id)
    {
        var ws = await _context.WorkSchedules.FindAsync(id);
        if (ws == null) return NotFound();

        _context.WorkSchedules.Remove(ws);
        await _context.SaveChangesAsync();
        return NoContent();
    }
}

public class WorkScheduleDto
{
    public int ScheduleId { get; set; }
    public int EmployeeId { get; set; }
    public string? EmployeeName { get; set; }
    public DateTime WorkDate { get; set; }
    public TimeSpan StartTime { get; set; }
    public TimeSpan EndTime { get; set; }
}

public class WorkScheduleCreateUpdateDto
{
    public int EmployeeId { get; set; }
    public DateTime WorkDate { get; set; }
    public TimeSpan StartTime { get; set; }
    public TimeSpan EndTime { get; set; }
}
