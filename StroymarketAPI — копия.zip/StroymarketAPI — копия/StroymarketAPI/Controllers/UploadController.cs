using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class UploadController : ControllerBase
{
    private readonly IWebHostEnvironment _env;

    public UploadController(IWebHostEnvironment env)
    {
        _env = env;
    }

    /// <summary>
    /// Загрузить изображение товара. Сохраняется в ImagePublic/products/
    /// Возвращает относительный путь вида ImagePublic/products/xxx.jpg
    /// </summary>
    [HttpPost("product-image")]
    [Authorize]
    public async Task<ActionResult<object>> UploadProductImage(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest(new { message = "Файл не выбран." });

        var allowed = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (string.IsNullOrEmpty(ext) || !allowed.Contains(ext))
            return BadRequest(new { message = "Допустимы только изображения: jpg, png, gif, webp" });

        var productsDir = Path.Combine(_env.ContentRootPath, "ImagePublic", "products");
        if (!Directory.Exists(productsDir))
            Directory.CreateDirectory(productsDir);

        var fileName = $"{Guid.NewGuid():N}{ext}";
        var fullPath = Path.Combine(productsDir, fileName);
        await using (var stream = new FileStream(fullPath, FileMode.Create))
            await file.CopyToAsync(stream);

        var relativePath = $"ImagePublic/products/{fileName}";
        return Ok(new { path = relativePath });
    }
}
