using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StroymarketAPI.Data;
using StroymarketAPI.Dtos;
using StroymarketAPI.Models;

namespace StroymarketAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly AppDbContext _context;

    public OrdersController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<OrderDto>>> GetOrders(
        [FromQuery] int? clientId,
        [FromQuery] string? status,
        [FromQuery] bool? archived)
    {
        var query = _context.Orders
            .Include(o => o.Client)
            .Include(o => o.Items)
                .ThenInclude(i => i.Product)
            .Include(o => o.Items)
                .ThenInclude(i => i.Service)
            .AsQueryable();

        if (clientId.HasValue)
        {
            query = query.Where(o => o.ClientId == clientId.Value);
        }

        if (!string.IsNullOrWhiteSpace(status))
        {
            query = query.Where(o => o.Status == status);
        }

        if (archived == true)
        {
            query = query.Where(o => o.IsArchived);
        }
        else
        {
            query = query.Where(o => !o.IsArchived);
        }

        if (!string.IsNullOrWhiteSpace(status) && status != "archived")
        {
            query = query.Where(o => !o.IsArchived);
        }

        var list = await query
            .OrderByDescending(o => o.OrderDate)
            .Select(o => new OrderDto
            {
                OrderId = o.OrderId,
                ClientId = o.ClientId,
                ClientName = o.ClientName ?? (o.Client != null ? o.Client.FullName : null),
                ClientPhone = o.ClientPhone ?? (o.Client != null ? o.Client.Phone : null),
                OrderDate = o.OrderDate,
                Status = o.Status,
                TotalAmount = o.TotalAmount,
                DeliveryType = o.DeliveryType,
                DeliveryAddress = o.DeliveryAddress,
                IsArchived = o.IsArchived,
                Items = o.Items.Select(i => new OrderItemDto
                {
                    OrderItemId = i.OrderItemId,
                    ProductId = i.ProductId,
                    ProductName = i.Product != null ? i.Product.Name : null,
                    ServiceId = i.ServiceId,
                    ServiceName = i.Service != null ? i.Service.Name : null,
                    Quantity = i.Quantity,
                    Price = i.Price
                }).ToList()
            })
            .ToListAsync();

        return Ok(list);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<OrderDto>> GetOrder(int id)
    {
        var o = await _context.Orders
            .Include(x => x.Client)
            .Include(x => x.Items)
                .ThenInclude(i => i.Product)
            .Include(x => x.Items)
                .ThenInclude(i => i.Service)
            .FirstOrDefaultAsync(x => x.OrderId == id);

        if (o == null)
            return NotFound();

        var dto = new OrderDto
        {
            OrderId = o.OrderId,
            ClientId = o.ClientId,
            ClientName = o.ClientName ?? o.Client?.FullName,
            ClientPhone = o.ClientPhone ?? o.Client?.Phone,
            OrderDate = o.OrderDate,
            Status = o.Status,
            TotalAmount = o.TotalAmount,
            DeliveryType = o.DeliveryType,
            DeliveryAddress = o.DeliveryAddress,
            IsArchived = o.IsArchived,
            Items = o.Items.Select(i => new OrderItemDto
            {
                OrderItemId = i.OrderItemId,
                ProductId = i.ProductId,
                ProductName = i.Product?.Name,
                ServiceId = i.ServiceId,
                ServiceName = i.Service?.Name,
                Quantity = i.Quantity,
                Price = i.Price
            }).ToList()
        };

        return Ok(dto);
    }

    [HttpPost]
    public async Task<ActionResult<OrderDto>> CreateOrder([FromBody] CreateOrderDto dto)
    {
        if (dto.Items == null || dto.Items.Count == 0)
        {
            return BadRequest(new { message = "Заказ должен содержать хотя бы одну позицию." });
        }

        using var transaction = await _context.Database.BeginTransactionAsync();

        var order = new Order
        {
            ClientId = dto.ClientId,
            ClientName = dto.ClientName,
            ClientPhone = dto.ClientPhone,
            DeliveryType = dto.DeliveryType,
            DeliveryAddress = dto.DeliveryAddress,
            OrderDate = DateTime.UtcNow,
            Status = dto.Status ?? "создан",
            TotalAmount = 0m
        };

        _context.Orders.Add(order);
        await _context.SaveChangesAsync();

        decimal total = 0m;

        foreach (var item in dto.Items)
        {
            var orderItem = new OrderItem
            {
                OrderId = order.OrderId,
                ProductId = item.ProductId,
                ServiceId = item.ServiceId,
                Quantity = item.Quantity,
                Price = item.Price
            };

            total += item.Price * item.Quantity;
            _context.OrderItems.Add(orderItem);

            if (item.ProductId.HasValue)
            {
                var product = await _context.Products.FindAsync(item.ProductId.Value);
                if (product != null)
                {
                    product.Quantity -= item.Quantity;
                }
            }
        }

        order.TotalAmount = total;
        await _context.SaveChangesAsync();
        await transaction.CommitAsync();

        return CreatedAtAction(nameof(GetOrder), new { id = order.OrderId }, new { order.OrderId });
    }

    [HttpPut("{id:int}/status")]
    public async Task<IActionResult> UpdateStatus(int id, [FromBody] UpdateOrderStatusDto dto)
    {
        var order = await _context.Orders.FindAsync(id);
        if (order == null)
            return NotFound();

        order.Status = dto.Status;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpPut("{id:int}/archive")]
    public async Task<IActionResult> ArchiveOrder(int id)
    {
        var order = await _context.Orders.FindAsync(id);
        if (order == null)
            return NotFound();

        order.IsArchived = true;
        await _context.SaveChangesAsync();
        return NoContent();
    }

    [HttpPut("{id:int}/unarchive")]
    public async Task<IActionResult> UnarchiveOrder(int id)
    {
        var order = await _context.Orders.FindAsync(id);
        if (order == null)
            return NotFound();

        order.IsArchived = false;
        await _context.SaveChangesAsync();
        return NoContent();
    }
}

