-- Добавить колонку image_path в таблицу products
-- Выполнить на существующей БД перед запуском API

ALTER TABLE stroy_market.products
ADD COLUMN IF NOT EXISTS image_path VARCHAR(500) NULL;
