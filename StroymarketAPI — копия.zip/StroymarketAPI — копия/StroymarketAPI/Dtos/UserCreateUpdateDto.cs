namespace StroymarketAPI.Dtos;

public class UserCreateUpdateDto
{
    public string Login { get; set; } = string.Empty;
    public string? Password { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public int RoleId { get; set; }
}

