using System;

namespace StroymarketAPI.Dtos;

public class SalaryDto
{
    public int SalaryId { get; set; }
    public int EmployeeId { get; set; }
    public string EmployeeName { get; set; } = string.Empty;
    public decimal BaseAmount { get; set; }
    public decimal Bonus { get; set; }
    public decimal Penalty { get; set; }
    public DateTime Period { get; set; }
}

public class SalaryCreateUpdateDto
{
    public int EmployeeId { get; set; }
    public decimal BaseAmount { get; set; }
    public decimal Bonus { get; set; }
    public decimal Penalty { get; set; }
    public DateTime Period { get; set; }
}

