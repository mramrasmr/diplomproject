namespace StroymarketAPI.Dtos;

public class LowStockProductDto
{
    public int ProductId { get; set; }
    public string Name { get; set; } = string.Empty;
    public int Quantity { get; set; }
}

public class DashboardSummaryDto
{
    public decimal TotalRevenue { get; set; }
    public int ProductsInStock { get; set; }
    public int StaffCount { get; set; }
    public int OrdersToday { get; set; }
    public List<LowStockProductDto> LowStockProducts { get; set; } = new();
}

