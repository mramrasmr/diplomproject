using System;
using System.Collections.Generic;

namespace StroymarketAPI.Dtos;

public class OrderItemDto
{
    public int OrderItemId { get; set; }
    public int? ProductId { get; set; }
    public string? ProductName { get; set; }
    public int? ServiceId { get; set; }
    public string? ServiceName { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
}

public class OrderDto
{
    public int OrderId { get; set; }
    public int? ClientId { get; set; }
    public string? ClientName { get; set; }
    public string? ClientPhone { get; set; }
    public DateTime OrderDate { get; set; }
    public string Status { get; set; } = string.Empty;
    public decimal TotalAmount { get; set; }
    public string? DeliveryType { get; set; }
    public string? DeliveryAddress { get; set; }
    public bool IsArchived { get; set; }
    public List<OrderItemDto> Items { get; set; } = new();
}

public class CreateOrderItemDto
{
    public int? ProductId { get; set; }
    public int? ServiceId { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
}

public class CreateOrderDto
{
    public int? ClientId { get; set; }
    public string? ClientName { get; set; }
    public string? ClientPhone { get; set; }
    public string? DeliveryType { get; set; }
    public string? DeliveryAddress { get; set; }
    public string Status { get; set; } = "создан";
    public List<CreateOrderItemDto> Items { get; set; } = new();
}

public class UpdateOrderStatusDto
{
    public string Status { get; set; } = string.Empty;
}

