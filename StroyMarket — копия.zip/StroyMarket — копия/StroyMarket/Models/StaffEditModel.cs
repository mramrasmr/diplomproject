namespace StroyMarket.Models;

public class StaffEditModel
{
    public int? UserId { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string RoleName { get; set; } = string.Empty;
    public int RoleId { get; set; }
    public string Login { get; set; } = string.Empty;
    public string? Password { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
}

