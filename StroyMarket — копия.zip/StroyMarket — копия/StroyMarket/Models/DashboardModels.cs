using System.Collections.Generic;

namespace StroyMarket.Models;

public class LowStockProductModel
{
    public int ProductId { get; set; }
    public string Name { get; set; } = string.Empty;
    public int Quantity { get; set; }
}

public class DashboardSummaryModel
{
    public decimal TotalRevenue { get; set; }
    public int ProductsInStock { get; set; }
    public int StaffCount { get; set; }
    public int OrdersToday { get; set; }
    public List<LowStockProductModel> LowStockProducts { get; set; } = new();
}

