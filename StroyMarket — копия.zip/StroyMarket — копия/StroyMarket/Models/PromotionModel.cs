using System;

namespace StroyMarket.Models;

public class PromotionModel
{
    public int PromotionId { get; set; }
    public string Title { get; set; } = string.Empty;
    public decimal DiscountValue { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string Status { get; set; } = string.Empty;
}
