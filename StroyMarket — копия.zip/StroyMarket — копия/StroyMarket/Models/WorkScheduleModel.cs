using System;

namespace StroyMarket.Models;

public class WorkScheduleModel
{
    public int ScheduleId { get; set; }
    public int EmployeeId { get; set; }
    public string? EmployeeName { get; set; }
    public DateTime WorkDate { get; set; }
    public TimeSpan StartTime { get; set; }
    public TimeSpan EndTime { get; set; }
    public string StartTimeDisplay => StartTime.ToString(@"hh\:mm");
    public string EndTimeDisplay => EndTime.ToString(@"hh\:mm");
}
