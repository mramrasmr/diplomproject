namespace StroyMarket.Models;

public class PromoCodeModel
{
    public int PromoCodeId { get; set; }
    public string Code { get; set; } = string.Empty;
    public int? PromotionId { get; set; }
    public string? PromotionTitle { get; set; }
    public decimal? DiscountValue { get; set; }
    public bool IsActive { get; set; }
}
