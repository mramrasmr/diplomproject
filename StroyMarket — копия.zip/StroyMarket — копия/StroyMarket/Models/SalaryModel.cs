using System;

namespace StroyMarket.Models;

public class SalaryModel
{
    public int SalaryId { get; set; }
    public int EmployeeId { get; set; }
    public string EmployeeName { get; set; } = string.Empty;
    public decimal BaseAmount { get; set; }
    public decimal Bonus { get; set; }
    public decimal Penalty { get; set; }
    public DateTime Period { get; set; }
    public decimal Total => BaseAmount + Bonus - Penalty;
}

