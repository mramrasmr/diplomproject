namespace StroyMarket.Models;

public class RoleModel
{
    public int RoleId { get; set; }
    public string RoleName { get; set; } = string.Empty;
}
