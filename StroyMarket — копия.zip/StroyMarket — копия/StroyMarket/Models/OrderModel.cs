using System;
using System.Collections.Generic;

namespace StroyMarket.Models;

public class OrderModel
{
    public int OrderId { get; set; }
    public int? ClientId { get; set; }
    public string? ClientName { get; set; }
    public string? ClientPhone { get; set; }
    public DateTime OrderDate { get; set; }
    public string Status { get; set; } = string.Empty;
    public decimal TotalAmount { get; set; }
    public string? DeliveryType { get; set; }
    public string? DeliveryAddress { get; set; }
    public bool IsArchived { get; set; }
    public List<OrderItemModel> Items { get; set; } = new();
}

public class OrderItemModel
{
    public int OrderItemId { get; set; }
    public int? ProductId { get; set; }
    public string? ProductName { get; set; }
    public int? ServiceId { get; set; }
    public string? ServiceName { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
    public string ItemName => ProductName ?? ServiceName ?? "—";
}
