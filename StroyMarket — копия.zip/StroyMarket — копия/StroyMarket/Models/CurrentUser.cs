using System;

namespace StroyMarket.Models
{
    /// <summary>
    /// Текущий авторизованный пользователь.
    /// Генерирует событие <see cref="Changed"/>, когда меняются его основные поля.
    /// Это позволяет ViewModel-ам обновлять заголовки (ФИО и роль) без пересоздания окон.
    /// </summary>
    public class CurrentUser
    {
        public static CurrentUser Instance { get; set; } = null!;

        /// <summary>Срабатывает при изменении любого публичного свойства (кроме Token).</summary>
        public static event Action? Changed;

        private static void RaiseChanged() => Changed?.Invoke();

        public int UserId
        {
            get => _userId;
            set
            {
                if (_userId != value)
                {
                    _userId = value;
                    RaiseChanged();
                }
            }
        }
        private int _userId;

        public string FullName
        {
            get => _fullName;
            set
            {
                if (!string.Equals(_fullName, value, StringComparison.Ordinal))
                {
                    _fullName = value;
                    RaiseChanged();
                }
            }
        }
        private string _fullName = string.Empty;

        public string RoleName
        {
            get => _roleName;
            set
            {
                if (!string.Equals(_roleName, value, StringComparison.Ordinal))
                {
                    _roleName = value;
                    RaiseChanged();
                }
            }
        }
        private string _roleName = string.Empty;

        public string Token { get; set; } = string.Empty;
    }
}