using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using StroyMarket.Models;

namespace StroyMarket.Services
{
    /// <summary>Добавляет Bearer-токен к каждому запросу (кроме логина).</summary>
    internal sealed class AuthHandler : DelegatingHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var token = ApiService.GetAuthToken();
            ApiService.Log($"AuthHandler: request to {request.RequestUri}, token length={token?.Length ?? 0}, will set header={!string.IsNullOrWhiteSpace(token)}");
            if (!string.IsNullOrWhiteSpace(token))
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            return await base.SendAsync(request, cancellationToken);
        }
    }

    public class ApiService
    {
        private static readonly string LogPath = Path.Combine(Path.GetTempPath(), "StroyMarket_api_log.txt");

        internal static void Log(string message)
        {
            try
            {
                var line = $"{DateTime.Now:HH:mm:ss.fff} {message}{Environment.NewLine}";
                File.AppendAllText(LogPath, line);
            }
            catch { /* ignore */ }
        }

        /// <summary>Токен, полученный при последнем успешном логине (резерв, если CurrentUser ещё не обновлён).</summary>
        internal static string? LastKnownToken { get; private set; }

        internal static string? GetAuthToken()
        {
            var fromCurrentUser = CurrentUser.Instance != null && !string.IsNullOrWhiteSpace(CurrentUser.Instance.Token);
            var token = fromCurrentUser ? CurrentUser.Instance!.Token : LastKnownToken;
            Log($"GetAuthToken: CurrentUser.Instance={CurrentUser.Instance != null}, CurrentUser.Token length={CurrentUser.Instance?.Token?.Length ?? 0}, LastKnownToken length={LastKnownToken?.Length ?? 0}, returning length={token?.Length ?? 0}");
            return token;
        }

        private readonly HttpClient _httpClient;
        private int _lastStatusCode;
        private string? _lastErrorBody;

        /// <summary>Текст последней ошибки API (код и тело ответа) для показа пользователю.</summary>
        public string GetLastError()
        {
            if (_lastStatusCode == 0) return "Нет данных об ошибке.";
            var body = string.IsNullOrWhiteSpace(_lastErrorBody) ? "" : $"\n{_lastErrorBody}";
            return $"HTTP {_lastStatusCode}{body}";
        }

        private void StoreError(HttpResponseMessage response, string? body)
        {
            _lastStatusCode = (int)response.StatusCode;
            _lastErrorBody = body;
        }

        /// <summary>Создаёт запрос с заголовком Authorization (для защищённых методов).</summary>
        private HttpRequestMessage CreateRequest(HttpMethod method, string requestUri, HttpContent? content = null)
        {
            var request = new HttpRequestMessage(method, requestUri);
            var token = GetAuthToken();
            if (!string.IsNullOrWhiteSpace(token))
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
            if (content != null)
                request.Content = content;
            return request;
        }

        public ApiService()
        {
            _httpClient = new HttpClient(new AuthHandler { InnerHandler = new HttpClientHandler() });
            _httpClient.BaseAddress = new Uri("http://localhost:5077");
        }

        public async Task<LoginResponse?> LoginAsync(string login, string password)
        {
            var request = new LoginRequest { Login = login, Password = password };
            var response = await _httpClient.PostAsJsonAsync("/api/auth/login", request);

            if (!response.IsSuccessStatusCode)
                return null;

            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var result = await response.Content.ReadFromJsonAsync<LoginResponse>(options);
            if (result != null && !string.IsNullOrWhiteSpace(result.Token))
            {
                LastKnownToken = result.Token;
                Log($"LoginAsync: success, Token length={result.Token.Length}, LastKnownToken set");
            }
            else
                Log($"LoginAsync: result Token empty or null. result={result != null}, Token length={result?.Token?.Length ?? 0}");
            return result;
        }

        public async Task<IReadOnlyList<ProductModel>?> GetProductsAsync(string? search = null, int? categoryId = null, string? status = null)
        {
            var query = new List<string>();
            if (!string.IsNullOrWhiteSpace(search)) query.Add($"search={Uri.EscapeDataString(search)}");
            if (categoryId.HasValue) query.Add($"categoryId={categoryId.Value}");
            if (!string.IsNullOrWhiteSpace(status)) query.Add($"status={Uri.EscapeDataString(status)}");
            var qs = query.Count > 0 ? "?" + string.Join("&", query) : "";
            var response = await _httpClient.GetAsync("/api/products" + qs);
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var result = await response.Content.ReadFromJsonAsync<List<ProductModel>>();
            return result ?? new List<ProductModel>();
        }

        public async Task<IReadOnlyList<CategoryModel>?> GetCategoriesAsync()
        {
            var response = await _httpClient.GetAsync("/api/categories");
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var result = await response.Content.ReadFromJsonAsync<List<CategoryModel>>();
            return result ?? new List<CategoryModel>();
        }

        public async Task<ProductModel?> CreateProductAsync(ProductModel model)
        {
            var payload = new ProductCreateUpdateDto
            {
                Name = model.Name,
                Description = model.Description,
                Price = model.Price,
                Quantity = model.Quantity,
                Status = model.Status,
                CategoryId = model.CategoryId,
                ImagePath = model.ImagePath
            };

            var response = await _httpClient.PostAsJsonAsync("/api/products", payload);
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            return await response.Content.ReadFromJsonAsync<ProductModel>();
        }

        public async Task<bool> UpdateProductAsync(ProductModel model)
        {
            var payload = new ProductCreateUpdateDto
            {
                Name = model.Name,
                Description = model.Description,
                Price = model.Price,
                Quantity = model.Quantity,
                Status = model.Status,
                CategoryId = model.CategoryId,
                ImagePath = model.ImagePath
            };

            var response = await _httpClient.PutAsJsonAsync($"/api/products/{model.ProductId}", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteProductAsync(int productId)
        {
            var response = await _httpClient.DeleteAsync($"/api/products/{productId}");
            return response.IsSuccessStatusCode;
        }

        /// <summary>Загрузить изображение товара. Возвращает относительный путь (ImagePublic/products/...) или null при ошибке.</summary>
        public async Task<string?> UploadProductImageAsync(string localFilePath)
        {
            await using var stream = File.OpenRead(localFilePath);
            var fileName = Path.GetFileName(localFilePath);
            using var content = new MultipartFormDataContent();
            content.Add(new StreamContent(stream), "file", fileName);

            using var request = CreateRequest(HttpMethod.Post, "/api/upload/product-image", content);
            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync();
                StoreError(response, body);
                return null;
            }

            var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
            var result = await response.Content.ReadFromJsonAsync<JsonElement>(options);
            return result.TryGetProperty("path", out var pathEl) ? pathEl.GetString() : null;
        }

        private class ProductCreateUpdateDto
        {
            public string Name { get; set; } = string.Empty;
            public string? Description { get; set; }
            public decimal Price { get; set; }
            public int Quantity { get; set; }
            public string Status { get; set; } = "активен";
            public int? CategoryId { get; set; }
            public string? ImagePath { get; set; }
        }

        public async Task<IReadOnlyList<RoleModel>?> GetRolesAsync()
        {
            var response = await _httpClient.GetAsync("/api/users/roles");
            if (!response.IsSuccessStatusCode) return null;
            var result = await response.Content.ReadFromJsonAsync<List<RoleModel>>();
            return result ?? new List<RoleModel>();
        }

        public async Task<IReadOnlyList<StaffModel>?> GetStaffAsync(string? search = null, int? roleId = null)
        {
            var query = new List<string>();
            if (!string.IsNullOrWhiteSpace(search)) query.Add($"search={Uri.EscapeDataString(search)}");
            if (roleId.HasValue) query.Add($"roleId={roleId.Value}");
            var qs = query.Count > 0 ? "?" + string.Join("&", query) : "";
            var response = await _httpClient.GetAsync("/api/users/staff" + qs);
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var result = await response.Content.ReadFromJsonAsync<List<StaffModel>>();
            return result ?? new List<StaffModel>();
        }

        public async Task<StaffModel?> CreateStaffAsync(StaffEditModel model)
        {
            var payload = new UserCreateUpdateDto
            {
                Login = model.Login,
                Password = model.Password,
                FullName = model.FullName,
                Email = model.Email,
                Phone = model.Phone,
                RoleId = model.RoleId
            };

            using var request = CreateRequest(HttpMethod.Post, "/api/users/staff", JsonContent.Create(payload));
            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync();
                StoreError(response, body);
                return null;
            }

            return await response.Content.ReadFromJsonAsync<StaffModel>();
        }

        public async Task<bool> UpdateStaffAsync(StaffEditModel model)
        {
            if (model.UserId is null)
                return false;

            var payload = new UserCreateUpdateDto
            {
                Login = model.Login,
                Password = model.Password,
                FullName = model.FullName,
                Email = model.Email,
                Phone = model.Phone,
                RoleId = model.RoleId
            };

            using var request = CreateRequest(HttpMethod.Put, $"/api/users/staff/{model.UserId}", JsonContent.Create(payload));
            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync();
                StoreError(response, body);
                return false;
            }
            return true;
        }

        public async Task<bool> DeleteStaffAsync(int userId)
        {
            using var request = CreateRequest(HttpMethod.Delete, $"/api/users/staff/{userId}");
            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync();
                StoreError(response, body);
                return false;
            }
            return true;
        }

        public async Task<IReadOnlyList<SalaryModel>?> GetSalariesAsync(int? employeeId = null)
        {
            var qs = employeeId.HasValue ? $"?employeeId={employeeId.Value}" : "";
            var response = await _httpClient.GetAsync("/api/salaries" + qs);
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var result = await response.Content.ReadFromJsonAsync<List<SalaryModel>>();
            return result ?? new List<SalaryModel>();
        }

        public async Task<SalaryModel?> CreateSalaryAsync(SalaryModel model)
        {
            var payload = new SalaryCreateUpdateDto
            {
                EmployeeId = model.EmployeeId,
                BaseAmount = model.BaseAmount,
                Bonus = model.Bonus,
                Penalty = model.Penalty,
                Period = model.Period
            };
            using var request = CreateRequest(HttpMethod.Post, "/api/salaries", JsonContent.Create(payload));
            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync();
                StoreError(response, body);
                return null;
            }
            return await response.Content.ReadFromJsonAsync<SalaryModel>();
        }

        public async Task<bool> UpdateSalaryAsync(SalaryModel model)
        {
            var payload = new SalaryCreateUpdateDto
            {
                EmployeeId = model.EmployeeId,
                BaseAmount = model.BaseAmount,
                Bonus = model.Bonus,
                Penalty = model.Penalty,
                Period = model.Period
            };
            using var request = CreateRequest(HttpMethod.Put, $"/api/salaries/{model.SalaryId}", JsonContent.Create(payload));
            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync();
                StoreError(response, body);
                return false;
            }
            return true;
        }

        public async Task<bool> DeleteSalaryAsync(int salaryId)
        {
            using var request = CreateRequest(HttpMethod.Delete, $"/api/salaries/{salaryId}");
            var response = await _httpClient.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadAsStringAsync();
                StoreError(response, body);
                return false;
            }
            return true;
        }

        public async Task<IReadOnlyList<OrderModel>?> GetOrdersAsync(string? status = null, bool archived = false)
        {
            var query = new List<string>();
            if (!string.IsNullOrWhiteSpace(status)) query.Add($"status={Uri.EscapeDataString(status)}");
            query.Add($"archived={archived}");
            var qs = "?" + string.Join("&", query);
            var response = await _httpClient.GetAsync("/api/orders" + qs);
            if (!response.IsSuccessStatusCode) return null;
            var result = await response.Content.ReadFromJsonAsync<List<OrderModel>>();
            return result ?? new List<OrderModel>();
        }

        public async Task<OrderModel?> GetOrderAsync(int orderId)
        {
            var response = await _httpClient.GetAsync($"/api/orders/{orderId}");
            if (!response.IsSuccessStatusCode) return null;
            return await response.Content.ReadFromJsonAsync<OrderModel>();
        }

        public async Task<bool> UpdateOrderStatusAsync(int orderId, string status)
        {
            var payload = new { status };
            var response = await _httpClient.PutAsJsonAsync($"/api/orders/{orderId}/status", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> ArchiveOrderAsync(int orderId)
        {
            var response = await _httpClient.PutAsync($"/api/orders/{orderId}/archive", null);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UnarchiveOrderAsync(int orderId)
        {
            var response = await _httpClient.PutAsync($"/api/orders/{orderId}/unarchive", null);
            return response.IsSuccessStatusCode;
        }

        public async Task<IReadOnlyList<PromotionModel>?> GetPromotionsAsync(string? status = null)
        {
            var qs = !string.IsNullOrWhiteSpace(status) ? $"?status={Uri.EscapeDataString(status)}" : "";
            var response = await _httpClient.GetAsync("/api/promotions" + qs);
            if (!response.IsSuccessStatusCode) return null;
            var result = await response.Content.ReadFromJsonAsync<List<PromotionModel>>();
            return result ?? new List<PromotionModel>();
        }

        public async Task<bool> CreatePromotionAsync(PromotionModel m)
        {
            var payload = new { m.Title, m.DiscountValue, m.StartDate, m.EndDate, m.Status };
            var response = await _httpClient.PostAsJsonAsync("/api/promotions", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UpdatePromotionAsync(PromotionModel m)
        {
            var payload = new { m.Title, m.DiscountValue, m.StartDate, m.EndDate, m.Status };
            var response = await _httpClient.PutAsJsonAsync($"/api/promotions/{m.PromotionId}", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeletePromotionAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"/api/promotions/{id}");
            return response.IsSuccessStatusCode;
        }

        public async Task<IReadOnlyList<PromoCodeModel>?> GetPromoCodesAsync(bool? isActive = null, int? promotionId = null)
        {
            var query = new List<string>();
            if (isActive.HasValue) query.Add($"isActive={isActive.Value}");
            if (promotionId.HasValue) query.Add($"promotionId={promotionId.Value}");
            var qs = query.Count > 0 ? "?" + string.Join("&", query) : "";
            var response = await _httpClient.GetAsync("/api/promocodes" + qs);
            if (!response.IsSuccessStatusCode) return null;
            var result = await response.Content.ReadFromJsonAsync<List<PromoCodeModel>>();
            return result ?? new List<PromoCodeModel>();
        }

        public async Task<bool> CreatePromoCodeAsync(PromoCodeModel m)
        {
            var payload = new { m.Code, m.PromotionId, m.DiscountValue, m.IsActive };
            var response = await _httpClient.PostAsJsonAsync("/api/promocodes", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UpdatePromoCodeAsync(PromoCodeModel m)
        {
            var payload = new { m.Code, m.PromotionId, m.DiscountValue, m.IsActive };
            var response = await _httpClient.PutAsJsonAsync($"/api/promocodes/{m.PromoCodeId}", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeletePromoCodeAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"/api/promocodes/{id}");
            return response.IsSuccessStatusCode;
        }

        public async Task<IReadOnlyList<ServiceModel>?> GetServicesAsync(int? categoryId = null)
        {
            var qs = categoryId.HasValue ? $"?categoryId={categoryId.Value}" : "";
            var response = await _httpClient.GetAsync("/api/services" + qs);
            if (!response.IsSuccessStatusCode) return null;
            var result = await response.Content.ReadFromJsonAsync<List<ServiceModel>>();
            return result ?? new List<ServiceModel>();
        }

        public async Task<bool> CreateServiceAsync(ServiceModel m)
        {
            var payload = new { m.Name, m.Description, m.Price, m.CategoryId };
            var response = await _httpClient.PostAsJsonAsync("/api/services", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UpdateServiceAsync(ServiceModel m)
        {
            var payload = new { m.Name, m.Description, m.Price, m.CategoryId };
            var response = await _httpClient.PutAsJsonAsync($"/api/services/{m.ServiceId}", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteServiceAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"/api/services/{id}");
            return response.IsSuccessStatusCode;
        }

        public async Task<IReadOnlyList<WorkScheduleModel>?> GetWorkSchedulesAsync(int? employeeId = null, DateTime? from = null, DateTime? to = null)
        {
            var query = new List<string>();
            if (employeeId.HasValue) query.Add($"employeeId={employeeId.Value}");
            if (from.HasValue) query.Add($"from={from.Value:yyyy-MM-dd}");
            if (to.HasValue) query.Add($"to={to.Value:yyyy-MM-dd}");
            var qs = query.Count > 0 ? "?" + string.Join("&", query) : "";
            var response = await _httpClient.GetAsync("/api/workschedules" + qs);
            if (!response.IsSuccessStatusCode) return null;
            var result = await response.Content.ReadFromJsonAsync<List<WorkScheduleModel>>();
            return result ?? new List<WorkScheduleModel>();
        }

        public async Task<bool> CreateWorkScheduleAsync(WorkScheduleModel m)
        {
            var payload = new { m.EmployeeId, m.WorkDate, m.StartTime, m.EndTime };
            var response = await _httpClient.PostAsJsonAsync("/api/workschedules", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> UpdateWorkScheduleAsync(WorkScheduleModel m)
        {
            var payload = new { m.EmployeeId, m.WorkDate, m.StartTime, m.EndTime };
            var response = await _httpClient.PutAsJsonAsync($"/api/workschedules/{m.ScheduleId}", payload);
            return response.IsSuccessStatusCode;
        }

        public async Task<bool> DeleteWorkScheduleAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"/api/workschedules/{id}");
            return response.IsSuccessStatusCode;
        }

        public async Task<DashboardSummaryModel?> GetDashboardSummaryAsync()
        {
            var response = await _httpClient.GetAsync("/api/dashboard/summary");
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            return await response.Content.ReadFromJsonAsync<DashboardSummaryModel>();
        }

        public async Task<byte[]?> DownloadProductsReportAsync()
        {
            var response = await _httpClient.GetAsync("/api/reports/products/csv");
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            return await response.Content.ReadAsByteArrayAsync();
        }

        public async Task<byte[]?> DownloadSalesReportAsync()
        {
            var response = await _httpClient.GetAsync("/api/reports/sales/csv");
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            return await response.Content.ReadAsByteArrayAsync();
        }

        private class UserCreateUpdateDto
        {
            public string Login { get; set; } = string.Empty;
            public string? Password { get; set; }
            public string FullName { get; set; } = string.Empty;
            public string? Email { get; set; }
            public string? Phone { get; set; }
            public int RoleId { get; set; }
        }

        private class SalaryCreateUpdateDto
        {
            public int EmployeeId { get; set; }
            public decimal BaseAmount { get; set; }
            public decimal Bonus { get; set; }
            public decimal Penalty { get; set; }
            public DateTime Period { get; set; }
        }
    }
}