using System.Windows;

namespace StroyMarket.Windows;

public partial class ServicesWin : Window
{
    public ServicesWin()
    {
        InitializeComponent();
        DataContext = new ViewModels.ServicesViewModel();
    }

    private void DashbordBtn_Click(object sender, RoutedEventArgs e) { new DashbordWin().Show(); Close(); }
    private void ProductsBtn_Click(object sender, RoutedEventArgs e) { new ProductsWin().Show(); Close(); }
    private void OrdersBtn_Click(object sender, RoutedEventArgs e) { new OrdersWin().Show(); Close(); }
    private void PromotionsBtn_Click(object sender, RoutedEventArgs e) { new PromotionsWin().Show(); Close(); }
    private void ServicesBtn_Click(object sender, RoutedEventArgs e) { }
    private void ScheduleBtn_Click(object sender, RoutedEventArgs e)
    {
        var win = Models.CurrentUser.Instance.RoleName == "Директор"
            ? (Window)new ScheduleWin()
            : new EmployeeScheduleWin();
        win.Show();
        Close();
    }
    private void ReportsBtn_Click(object sender, RoutedEventArgs e) { new ReportsWin().Show(); Close(); }
    private void StaffBtn_Click(object sender, RoutedEventArgs e) { new StaffWin().Show(); Close(); }
    private void SalaryBtn_Click(object sender, RoutedEventArgs e) { new SalaryWin().Show(); Close(); }
    private void LogoutBtn_Click(object sender, RoutedEventArgs e) { new AuthorizationWin().Show(); Close(); }
    private void ProfileBtn_Click(object sender, RoutedEventArgs e) { new ProfileWin { Owner = this }.ShowDialog(); }
}
