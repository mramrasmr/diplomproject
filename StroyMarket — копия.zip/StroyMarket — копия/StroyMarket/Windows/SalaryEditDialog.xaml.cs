using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using StroyMarket.Models;
using StroyMarket.Services;

namespace StroyMarket.Windows;

public partial class SalaryEditDialog : Window
{
    private readonly ApiService _apiService = new();

    public SalaryModel Model { get; }

    /// <summary>Обёртка для привязки DatePicker (DateTime?) к Model.Period (DateTime).</summary>
    public DateTime? PeriodDate
    {
        get => Model.Period;
        set => Model.Period = value.HasValue ? value.Value : Model.Period;
    }

    public ObservableCollection<StaffModel> Employees { get; } = new();

    public SalaryEditDialog(SalaryModel model)
    {
        InitializeComponent();
        Model = model;
        DataContext = this;
        _ = LoadEmployeesAsync();
    }

    private async Task LoadEmployeesAsync()
    {
        try
        {
            Employees.Clear();
            var list = await _apiService.GetStaffAsync();
            if (list != null)
            {
                foreach (var e in list)
                {
                    Employees.Add(e);
                }
            }
        }
        catch
        {
        }
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (Model.EmployeeId <= 0)
        {
            MessageBox.Show("Выберите сотрудника.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (Model.BaseAmount < 0)
        {
            MessageBox.Show("Оклад не может быть отрицательным.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (Model.Bonus < 0)
        {
            MessageBox.Show("Премия не может быть отрицательной.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (Model.Penalty < 0)
        {
            MessageBox.Show("Штраф не может быть отрицательным.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!PeriodDate.HasValue)
        {
            MessageBox.Show("Укажите период.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        DialogResult = true;
        Close();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        SalaryWin salaryWin = new SalaryWin();
        salaryWin.Show();
        this.Close();
    }
}
