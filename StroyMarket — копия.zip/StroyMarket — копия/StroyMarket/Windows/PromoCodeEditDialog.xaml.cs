using System.Collections.Generic;
using System.Windows;
using StroyMarket.Models;

namespace StroyMarket.Windows;

public partial class PromoCodeEditDialog : Window
{
    public PromoCodeModel Model { get; }
    public ICollection<PromotionModel> Promotions { get; }

    public PromoCodeEditDialog(PromoCodeModel model, IEnumerable<PromotionModel> promotions)
    {
        InitializeComponent();
        Model = model;
        Promotions = new List<PromotionModel> { new PromotionModel { PromotionId = 0, Title = "Без привязки" } };
        foreach (var p in promotions)
            Promotions.Add(p);
        DataContext = this;
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Model.Code))
        {
            MessageBox.Show("Введите код промокода.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (Model.PromotionId == 0) Model.PromotionId = null;
        if (!Model.PromotionId.HasValue)
        {
            if (!Model.DiscountValue.HasValue)
            {
                MessageBox.Show("Укажите скидку % (промокод не привязан к акции).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            var d = Model.DiscountValue.Value;
            if (d < 0 || d > 100)
            {
                MessageBox.Show("Скидка должна быть от 0 до 100%.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
        }
        DialogResult = true;
        Close();
    }
}
