using System;
using System.Windows;
using StroyMarket.Models;

namespace StroyMarket.Windows;

public partial class PromotionEditDialog : Window
{
    public PromotionModel Model { get; }

    public string[] AvailableStatuses { get; } = { "активна", "неактивна" };

    public PromotionEditDialog(PromotionModel model)
    {
        InitializeComponent();
        Model = model;
        DataContext = this;
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Model.Title))
        {
            MessageBox.Show("Введите название акции.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (Model.DiscountValue < 0 || Model.DiscountValue > 100)
        {
            MessageBox.Show("Скидка должна быть от 0 до 100%.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        var start = Model.StartDate.Date;
        var end = Model.EndDate.Date;
        if (start > end)
        {
            MessageBox.Show("Дата окончания не может быть раньше даты начала.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (Model.PromotionId == 0 && start < DateTime.Today)
        {
            MessageBox.Show("Дата начала новой акции не может быть в прошлом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        DialogResult = true;
        Close();
    }
}
