using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using StroyMarket.Models;
using StroyMarket.Services;

namespace StroyMarket.Windows;

public partial class ProductEditDialog : Window
{
    private readonly ApiService _apiService = new();

    public ProductModel Model { get; }
    public ObservableCollection<CategoryModel> Categories { get; } = new();
    public ObservableCollection<string> AvailableStatuses { get; } = new(new[] { "активен", "неактивен" });

    public ProductEditDialog(ProductModel model)
    {
        InitializeComponent();
        Model = model;
        DataContext = this;
        _ = LoadCategoriesAsync();
        UpdateImageDisplay();
    }

    private async Task LoadCategoriesAsync()
    {
        try
        {
            Categories.Clear();
            var list = await _apiService.GetCategoriesAsync();
            if (list != null)
            {
                foreach (var c in list)
                {
                    Categories.Add(c);
                }
            }
        }
        catch
        {
        }
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Model.Name))
        {
            MessageBox.Show("Введите наименование товара.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!decimal.TryParse(Model.Price.ToString(), out var price) || price < 0)
        {
            MessageBox.Show("Цена должна быть неотрицательным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!int.TryParse(Model.Quantity.ToString(), out var qty) || qty < 0)
        {
            MessageBox.Show("Количество должно быть неотрицательным целым числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (string.IsNullOrWhiteSpace(Model.Status))
        {
            MessageBox.Show("Выберите статус.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        DialogResult = true;
        Close();
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        ProductsWin productsWin = new ProductsWin();
        productsWin.Show();
        this.Close();
    }

    private void UpdateImageDisplay()
    {
        if (string.IsNullOrWhiteSpace(Model.ImagePath))
        {
            ProductImage.Source = null;
            return;
        }
        try
        {
            var path = Model.ImagePath.TrimStart('/');
            var uri = new Uri($"http://localhost:5077/{path}", UriKind.Absolute);
            ProductImage.Source = new BitmapImage(uri);
        }
        catch
        {
            ProductImage.Source = null;
        }
    }

    private async void SelectImage_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new OpenFileDialog
        {
            Filter = "Изображения|*.jpg;*.jpeg;*.png;*.gif;*.webp|Все файлы|*.*",
            Title = "Выберите изображение товара"
        };
        if (dlg.ShowDialog() != true)
            return;

        var path = await _apiService.UploadProductImageAsync(dlg.FileName);
        if (path == null)
        {
            MessageBox.Show("Не удалось загрузить изображение. " + _apiService.GetLastError(),
                "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        Model.ImagePath = path;
        UpdateImageDisplay();
    }

    private void RemoveImage_Click(object sender, RoutedEventArgs e)
    {
        Model.ImagePath = null;
        UpdateImageDisplay();
    }
}

