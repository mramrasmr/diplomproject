using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using StroyMarket.ViewModels;

namespace StroyMarket.Windows
{
    public partial class AuthorizationWin : Window
    {
        public AuthorizationWin()
        {
            InitializeComponent();
            var vm = new AuthorizationViewModel();
            vm.LoginSucceeded += VmOnLoginSucceeded;
            DataContext = vm;
        }

        private void OutBtn_Click(object sender, RoutedEventArgs e)
        {
            ScreenSaverWin screenSaverWin = new ScreenSaverWin();
            screenSaverWin.Show();
            this.Close();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is AuthorizationViewModel vm)
            {
                vm.Password = PasswordBox.Password;
            }
        }

        private void PasswordBox_OnPasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is AuthorizationViewModel vm)
            {
                vm.Password = PasswordBox.Password;
            }
        }

        private void VmOnLoginSucceeded()
        {
            Dispatcher.Invoke(() =>
            {
                var dashbordWin = new DashbordWin();
                dashbordWin.Show();
                Close();
            });
        }
    }
}
