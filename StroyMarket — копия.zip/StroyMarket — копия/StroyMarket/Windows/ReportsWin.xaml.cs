using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using StroyMarket.ViewModels;

namespace StroyMarket.Windows
{
    public partial class ReportsWin : Window
    {
        public ReportsWin()
        {
            InitializeComponent();
            DataContext = new ReportsViewModel();
        }

        private void DashbordBtn_Click(object sender, RoutedEventArgs e)
        {
            var win = new DashbordWin();
            win.Show();
            Close();
        }

        private void ProductsBtn_Click(object sender, RoutedEventArgs e)
        {
            new ProductsWin().Show();
            Close();
        }

        private void OrdersBtn_Click(object sender, RoutedEventArgs e)
        {
            new OrdersWin().Show();
            Close();
        }

        private void PromotionsBtn_Click(object sender, RoutedEventArgs e)
        {
            new PromotionsWin().Show();
            Close();
        }

        private void ServicesBtn_Click(object sender, RoutedEventArgs e)
        {
            new ServicesWin().Show();
            Close();
        }

        private void ScheduleBtn_Click(object sender, RoutedEventArgs e)
        {
            var win = Models.CurrentUser.Instance.RoleName == "Директор"
                ? (Window)new ScheduleWin()
                : new EmployeeScheduleWin();
            win.Show();
            Close();
        }

        private void ReportsBtn_Click(object sender, RoutedEventArgs e)
        {
        }

        private void StaffBtn_Click(object sender, RoutedEventArgs e)
        {
            var win = new StaffWin();
            win.Show();
            Close();
        }

        private void SalaryBtn_Click(object sender, RoutedEventArgs e)
        {
            var win = new SalaryWin();
            win.Show();
            Close();
        }

        private void LogoutBtn_Click(object sender, RoutedEventArgs e)
        {
            var auth = new AuthorizationWin();
            auth.Show();
            Close();
        }

        private void ProfileBtn_Click(object sender, RoutedEventArgs e)
        {
            var profile = new ProfileWin
            {
                Owner = this
            };
            profile.ShowDialog();
        }
    }
}
