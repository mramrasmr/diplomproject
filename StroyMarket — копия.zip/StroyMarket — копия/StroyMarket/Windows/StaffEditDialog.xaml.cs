using System.Collections.ObjectModel;
using System.Windows;
using StroyMarket.Models;

namespace StroyMarket.Windows;

public partial class StaffEditDialog : Window
{
    public StaffEditModel Model { get; }

    public ObservableCollection<RoleItem> AvailableRoles { get; } = new(new[]
    {
        new RoleItem { RoleId = 2, Name = "Сотрудник" },
        new RoleItem { RoleId = 3, Name = "Директор" }
    });

    public StaffEditDialog(StaffEditModel model)
    {
        InitializeComponent();
        Model = model;
        DataContext = this;
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Model.FullName))
        {
            MessageBox.Show("Введите ФИО сотрудника.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (string.IsNullOrWhiteSpace(Model.Login))
        {
            MessageBox.Show("Введите логин.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        Model.Password = string.IsNullOrWhiteSpace(PasswordBox.Password) ? null : PasswordBox.Password;
        var isNew = Model.UserId == null || Model.UserId == 0;
        if (isNew && string.IsNullOrWhiteSpace(Model.Password))
        {
            MessageBox.Show("Для нового сотрудника укажите пароль.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (Model.RoleId <= 0)
        {
            MessageBox.Show("Выберите роль.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        DialogResult = true;
        Close();
    }

    public class RoleItem
    {
        public int RoleId { get; set; }
        public string Name { get; set; } = string.Empty;
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        StaffWin staffWin = new StaffWin();
        staffWin.Name = Name;
        this.Close();
    }
}

