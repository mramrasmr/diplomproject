using System;
using System.Collections.Generic;
using System.Windows;
using StroyMarket.Models;

namespace StroyMarket.Windows;

public partial class ScheduleEditDialog : Window
{
    public WorkScheduleModel Model { get; }
    public ICollection<StaffModel> Staff { get; }

    public ScheduleEditDialog(WorkScheduleModel model, List<StaffModel> staff)
    {
        InitializeComponent();
        Model = model;
        Staff = staff;
        DataContext = this;
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (!TimeSpan.TryParse(StartTimeBox.Text, out var start))
        {
            MessageBox.Show("Введите время начала в формате ЧЧ:мм (например 09:00).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!TimeSpan.TryParse(EndTimeBox.Text, out var end))
        {
            MessageBox.Show("Введите время окончания в формате ЧЧ:мм (например 18:00).", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (end <= start)
        {
            MessageBox.Show("Время окончания должно быть позже времени начала.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        Model.StartTime = start;
        Model.EndTime = end;
        if (Model.EmployeeId <= 0)
        {
            MessageBox.Show("Выберите сотрудника.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (Model.WorkDate.Date < DateTime.Today)
        {
            MessageBox.Show("Дата работы не может быть в прошлом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        DialogResult = true;
        Close();
    }
}
