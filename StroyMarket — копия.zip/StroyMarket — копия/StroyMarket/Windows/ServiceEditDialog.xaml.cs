using System.Collections.Generic;
using System.Windows;
using StroyMarket.Models;

namespace StroyMarket.Windows;

public partial class ServiceEditDialog : Window
{
    public ServiceModel Model { get; }
    public List<CategoryModel> Categories { get; }

    public ServiceEditDialog(ServiceModel model, IEnumerable<CategoryModel> categories)
    {
        InitializeComponent();
        Model = model;
        if (model.CategoryId == null) model.CategoryId = 0;
        Categories = new List<CategoryModel> { new CategoryModel { CategoryId = 0, Name = "Без категории" } };
        foreach (var c in categories)
            Categories.Add(c);
        DataContext = this;
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Model.Name))
        {
            MessageBox.Show("Введите название услуги.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (!decimal.TryParse(Model.Price.ToString(), out var price) || price < 0)
        {
            MessageBox.Show("Цена должна быть неотрицательным числом.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (Model.CategoryId == 0) Model.CategoryId = null;
        DialogResult = true;
        Close();
    }
}
