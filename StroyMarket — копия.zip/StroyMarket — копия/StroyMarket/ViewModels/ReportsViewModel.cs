using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Microsoft.Win32;
using StroyMarket.Models;
using StroyMarket.Services;

namespace StroyMarket.ViewModels;

public class ReportsViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;

    public ICommand ExportProductsReportCommand { get; }
    public ICommand ExportSalesReportCommand { get; }

    public ReportsViewModel()
    {
        CurrentUser.Changed += OnCurrentUserChanged;
        ExportProductsReportCommand = new RelayCommand(async _ => await ExportProductsAsync());
        ExportSalesReportCommand = new RelayCommand(async _ => await ExportSalesAsync());
    }

    private void OnCurrentUserChanged()
    {
        OnPropertyChanged(nameof(FullName));
        OnPropertyChanged(nameof(RoleName));
    }

    private async Task ExportProductsAsync()
    {
        await ExportAsync(
            "Отчет по товарам",
            "products_report.csv",
            _apiService.DownloadProductsReportAsync);
    }

    private async Task ExportSalesAsync()
    {
        await ExportAsync(
            "Отчет по продажам",
            "sales_report.csv",
            _apiService.DownloadSalesReportAsync);
    }

    private async Task ExportAsync(string title, string defaultFileName, Func<Task<byte[]?>> loader)
    {
        try
        {
            var data = await loader();
            if (data == null)
            {
                MessageBox.Show("Не удалось получить данные отчета с сервера.", title,
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Title = title,
                FileName = defaultFileName,
                Filter = "CSV файлы (*.csv)|*.csv|Все файлы (*.*)|*.*"
            };

            if (dialog.ShowDialog() == true)
            {
                File.WriteAllBytes(dialog.FileName, data);
                MessageBox.Show("Отчет успешно сохранен. Его можно открыть в Excel.", title,
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка формирования отчета: {ex.Message}", title,
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}

