using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using StroyMarket.Models;
using StroyMarket.Services;
using StroyMarket.Windows;

namespace StroyMarket.ViewModels;

public class PromotionsViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;

    public ObservableCollection<PromotionModel> Promotions { get; } = new();
    public ObservableCollection<PromoCodeModel> PromoCodes { get; } = new();

    private PromotionModel? _selectedPromotion;
    public PromotionModel? SelectedPromotion
    {
        get => _selectedPromotion;
        set => SetProperty(ref _selectedPromotion, value);
    }

    private PromoCodeModel? _selectedPromoCode;
    public PromoCodeModel? SelectedPromoCode
    {
        get => _selectedPromoCode;
        set => SetProperty(ref _selectedPromoCode, value);
    }

    private string? _statusFilter = "Все статусы";
    public string? StatusFilter
    {
        get => _statusFilter;
        set { if (SetProperty(ref _statusFilter, value)) _ = LoadPromotionsAsync(); }
    }

    private string _promoActiveFilter = "";
    public string PromoActiveFilter
    {
        get => _promoActiveFilter;
        set { if (SetProperty(ref _promoActiveFilter, value ?? "")) _ = LoadPromoCodesAsync(); }
    }

    public string[] StatusOptions { get; } = { "Все статусы", "активна", "неактивна" };
    public List<PromoFilterItem> PromoActiveOptions { get; } = new()
    {
        new PromoFilterItem("", "— Все —"),
        new PromoFilterItem("active", "Активные"),
        new PromoFilterItem("inactive", "Неактивные")
    };

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                ((RelayCommand)ReloadPromotionsCommand).RaiseCanExecuteChanged();
                ((RelayCommand)ReloadPromoCodesCommand).RaiseCanExecuteChanged();
                ((RelayCommand)AddPromotionCommand).RaiseCanExecuteChanged();
                ((RelayCommand)EditPromotionCommand).RaiseCanExecuteChanged();
                ((RelayCommand)DeletePromotionCommand).RaiseCanExecuteChanged();
                ((RelayCommand)AddPromoCodeCommand).RaiseCanExecuteChanged();
                ((RelayCommand)EditPromoCodeCommand).RaiseCanExecuteChanged();
                ((RelayCommand)DeletePromoCodeCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public ICommand ReloadPromotionsCommand { get; }
    public ICommand ReloadPromoCodesCommand { get; }
    public ICommand AddPromotionCommand { get; }
    public ICommand EditPromotionCommand { get; }
    public ICommand DeletePromotionCommand { get; }
    public ICommand AddPromoCodeCommand { get; }
    public ICommand EditPromoCodeCommand { get; }
    public ICommand DeletePromoCodeCommand { get; }

    public PromotionsViewModel()
    {
        CurrentUser.Changed += () => { OnPropertyChanged(nameof(FullName)); OnPropertyChanged(nameof(RoleName)); };
        ReloadPromotionsCommand = new RelayCommand(async _ => await LoadPromotionsAsync(), _ => !IsBusy);
        ReloadPromoCodesCommand = new RelayCommand(async _ => await LoadPromoCodesAsync(), _ => !IsBusy);
        AddPromotionCommand = new RelayCommand(async _ => await AddPromotionAsync(), _ => !IsBusy);
        EditPromotionCommand = new RelayCommand(async p => await EditPromotionAsync(p as PromotionModel), p => !IsBusy && p is PromotionModel);
        DeletePromotionCommand = new RelayCommand(async p => await DeletePromotionAsync(p as PromotionModel), p => !IsBusy && p is PromotionModel);
        AddPromoCodeCommand = new RelayCommand(async _ => await AddPromoCodeAsync(), _ => !IsBusy);
        EditPromoCodeCommand = new RelayCommand(async p => await EditPromoCodeAsync(p as PromoCodeModel), p => !IsBusy && p is PromoCodeModel);
        DeletePromoCodeCommand = new RelayCommand(async p => await DeletePromoCodeAsync(p as PromoCodeModel), p => !IsBusy && p is PromoCodeModel);
        _ = LoadPromotionsAsync();
        _ = LoadPromoCodesAsync();
    }

    private async Task LoadPromotionsAsync()
    {
        IsBusy = true;
        try
        {
            Promotions.Clear();
            var status = (StatusFilter == "Все статусы" || string.IsNullOrWhiteSpace(StatusFilter)) ? null : StatusFilter;
            var items = await _apiService.GetPromotionsAsync(status);
            if (items != null) foreach (var p in items) Promotions.Add(p);
        }
        finally { IsBusy = false; }
    }

    private async Task LoadPromoCodesAsync()
    {
        IsBusy = true;
        try
        {
            PromoCodes.Clear();
            bool? isActive = PromoActiveFilter == "active" ? true : PromoActiveFilter == "inactive" ? false : null;
            var items = await _apiService.GetPromoCodesAsync(isActive, null);
            if (items != null) foreach (var p in items) PromoCodes.Add(p);
        }
        finally { IsBusy = false; }
    }

    private async Task AddPromotionAsync()
    {
        var dlg = new PromotionEditDialog(new PromotionModel { Status = "активна", StartDate = DateTime.Today, EndDate = DateTime.Today.AddMonths(1) });
        if (dlg.ShowDialog() != true) return;
        IsBusy = true;
        try
        {
            if (await _apiService.CreatePromotionAsync(dlg.Model))
                await LoadPromotionsAsync();
            else MessageBox.Show("Ошибка создания акции.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    private async Task EditPromotionAsync(PromotionModel? p)
    {
        if (p == null) return;
        var copy = new PromotionModel { PromotionId = p.PromotionId, Title = p.Title, DiscountValue = p.DiscountValue, StartDate = p.StartDate, EndDate = p.EndDate, Status = p.Status };
        var dlg = new PromotionEditDialog(copy);
        if (dlg.ShowDialog() != true) return;
        IsBusy = true;
        try
        {
            if (await _apiService.UpdatePromotionAsync(dlg.Model))
                await LoadPromotionsAsync();
            else MessageBox.Show("Ошибка сохранения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    private async Task DeletePromotionAsync(PromotionModel? p)
    {
        if (p == null) return;
        if (MessageBox.Show($"Удалить акцию \"{p.Title}\"?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        IsBusy = true;
        try
        {
            if (await _apiService.DeletePromotionAsync(p.PromotionId))
                Promotions.Remove(p);
            else MessageBox.Show("Ошибка удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    private async Task AddPromoCodeAsync()
    {
        var dlg = new PromoCodeEditDialog(new PromoCodeModel { IsActive = true }, Promotions);
        if (dlg.ShowDialog() != true) return;
        IsBusy = true;
        try
        {
            if (await _apiService.CreatePromoCodeAsync(dlg.Model))
                await LoadPromoCodesAsync();
            else MessageBox.Show("Ошибка создания промокода. Возможно, код уже существует.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    private async Task EditPromoCodeAsync(PromoCodeModel? p)
    {
        if (p == null) return;
        var copy = new PromoCodeModel { PromoCodeId = p.PromoCodeId, Code = p.Code, PromotionId = p.PromotionId, DiscountValue = p.DiscountValue, IsActive = p.IsActive };
        var dlg = new PromoCodeEditDialog(copy, Promotions);
        if (dlg.ShowDialog() != true) return;
        IsBusy = true;
        try
        {
            if (await _apiService.UpdatePromoCodeAsync(dlg.Model))
                await LoadPromoCodesAsync();
            else MessageBox.Show("Ошибка сохранения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    private async Task DeletePromoCodeAsync(PromoCodeModel? p)
    {
        if (p == null) return;
        if (MessageBox.Show($"Удалить промокод \"{p.Code}\"?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        IsBusy = true;
        try
        {
            if (await _apiService.DeletePromoCodeAsync(p.PromoCodeId))
                PromoCodes.Remove(p);
            else MessageBox.Show("Ошибка удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }
}

public class PromoFilterItem
{
    public string Value { get; set; } = "";
    public string Display { get; set; } = "";
    public PromoFilterItem(string value, string display) { Value = value; Display = display; }
}
