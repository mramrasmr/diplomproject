using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using StroyMarket.Models;
using StroyMarket.Services;

namespace StroyMarket.ViewModels;

public class AuthorizationViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();

    public event Action? LoginSucceeded;

    private string _login = string.Empty;
    public string Login
    {
        get => _login;
        set
        {
            if (SetProperty(ref _login, value))
            {
                ((RelayCommand)LoginCommand).RaiseCanExecuteChanged();
            }
        }
    }

    private string _password = string.Empty;
    public string Password
    {
        get => _password;
        set
        {
            if (SetProperty(ref _password, value))
            {
                ((RelayCommand)LoginCommand).RaiseCanExecuteChanged();
            }
        }
    }

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                ((RelayCommand)LoginCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public ICommand LoginCommand { get; }

    public AuthorizationViewModel()
    {
        LoginCommand = new RelayCommand(async _ => await LoginAsync(), _ => CanLogin());
    }

    private bool CanLogin()
    {
        return !IsBusy
               && !string.IsNullOrWhiteSpace(Login)
               && !string.IsNullOrWhiteSpace(Password);
    }

    private async Task LoginAsync()
    {
        IsBusy = true;

        try
        {
            var result = await _apiService.LoginAsync(Login, Password);
            if (result != null)
            {
                CurrentUser.Instance = new CurrentUser
                {
                    UserId = result.UserId,
                    FullName = result.FullName,
                    RoleName = result.RoleName,
                    Token = result.Token
                };

                LoginSucceeded?.Invoke();
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка входа: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }
}

