using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using StroyMarket.Models;
using StroyMarket.Services;
using StroyMarket.Windows;

namespace StroyMarket.ViewModels;

public class ScheduleViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;

    public bool IsDirector => CurrentUser.Instance.RoleName == "Директор";

    public ObservableCollection<WorkScheduleModel> Schedules { get; } = new();
    public ObservableCollection<StaffModel> StaffList { get; } = new();

    private StaffModel? _selectedEmployeeFilter;
    public StaffModel? SelectedEmployeeFilter
    {
        get => _selectedEmployeeFilter;
        set { if (SetProperty(ref _selectedEmployeeFilter, value)) _ = LoadAsync(); }
    }

    private DateTime _filterFrom = DateTime.Today;
    public DateTime FilterFrom
    {
        get => _filterFrom;
        set
        {
            var v = value.Date;
            if (v > _filterTo.Date) SetProperty(ref _filterTo, v);
            if (SetProperty(ref _filterFrom, v)) _ = LoadAsync();
        }
    }

    private DateTime _filterTo = DateTime.Today.AddDays(7);
    public DateTime FilterTo
    {
        get => _filterTo;
        set
        {
            var v = value.Date;
            if (v < _filterFrom.Date) SetProperty(ref _filterFrom, v);
            if (SetProperty(ref _filterTo, v)) _ = LoadAsync();
        }
    }

    private WorkScheduleModel? _selectedSchedule;
    public WorkScheduleModel? SelectedSchedule
    {
        get => _selectedSchedule;
        set => SetProperty(ref _selectedSchedule, value);
    }

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                ((RelayCommand)ReloadCommand).RaiseCanExecuteChanged();
                ((RelayCommand)AddCommand).RaiseCanExecuteChanged();
                ((RelayCommand)EditCommand).RaiseCanExecuteChanged();
                ((RelayCommand)DeleteCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public ICommand ReloadCommand { get; }
    public ICommand AddCommand { get; }
    public ICommand EditCommand { get; }
    public ICommand DeleteCommand { get; }

    public ScheduleViewModel()
    {
        CurrentUser.Changed += () =>
        {
            OnPropertyChanged(nameof(FullName));
            OnPropertyChanged(nameof(RoleName));
            OnPropertyChanged(nameof(IsDirector));
        };

        ReloadCommand = new RelayCommand(async _ => await LoadAsync(), _ => !IsBusy);
        AddCommand = new RelayCommand(async _ => await AddAsync(), _ => !IsBusy && IsDirector);
        EditCommand = new RelayCommand(async p => await EditAsync(p as WorkScheduleModel), p => !IsBusy && IsDirector && p is WorkScheduleModel);
        DeleteCommand = new RelayCommand(async p => await DeleteAsync(p as WorkScheduleModel), p => !IsBusy && IsDirector && p is WorkScheduleModel);
        _ = LoadAsync();
    }

    private async Task LoadAsync()
    {
        IsBusy = true;
        try
        {
            Schedules.Clear();

            if (StaffList.Count == 0)
            {
                var staff = await _apiService.GetStaffAsync();
                if (staff != null)
                {
                    StaffList.Add(new StaffModel { UserId = 0, FullName = "Все сотрудники" });
                    foreach (var s in staff) StaffList.Add(s);
                }
                if (IsDirector && _selectedEmployeeFilter == null && StaffList.Count > 0)
                {
                    _selectedEmployeeFilter = StaffList[0];
                    OnPropertyChanged(nameof(SelectedEmployeeFilter));
                }
            }

            int? empId = null;
            if (IsDirector && SelectedEmployeeFilter != null && SelectedEmployeeFilter.UserId != 0)
                empId = SelectedEmployeeFilter.UserId;
            else if (!IsDirector)
                empId = CurrentUser.Instance.UserId;

            var items = await _apiService.GetWorkSchedulesAsync(empId, FilterFrom, FilterTo);
            if (items != null)
                foreach (var ws in items)
                    Schedules.Add(ws);
        }
        finally { IsBusy = false; }
    }

    private async Task AddAsync()
    {
        var staff = StaffList.Where(s => s.UserId != 0).ToList();
        if (staff.Count == 0) { MessageBox.Show("Нет сотрудников для назначения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
        var dlg = new ScheduleEditDialog(new WorkScheduleModel { WorkDate = FilterFrom, StartTime = TimeSpan.FromHours(9), EndTime = TimeSpan.FromHours(18) }, staff);
        if (dlg.ShowDialog() != true) return;
        IsBusy = true;
        try
        {
            if (await _apiService.CreateWorkScheduleAsync(dlg.Model))
                await LoadAsync();
            else MessageBox.Show("Ошибка создания.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    private async Task EditAsync(WorkScheduleModel? ws)
    {
        if (ws == null) return;
        var staff = StaffList.Where(s => s.UserId != 0).ToList();
        var copy = new WorkScheduleModel { ScheduleId = ws.ScheduleId, EmployeeId = ws.EmployeeId, WorkDate = ws.WorkDate, StartTime = ws.StartTime, EndTime = ws.EndTime };
        var dlg = new ScheduleEditDialog(copy, staff);
        if (dlg.ShowDialog() != true) return;
        IsBusy = true;
        try
        {
            if (await _apiService.UpdateWorkScheduleAsync(dlg.Model))
                await LoadAsync();
            else MessageBox.Show("Ошибка сохранения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    private async Task DeleteAsync(WorkScheduleModel? ws)
    {
        if (ws == null) return;
        if (MessageBox.Show("Удалить запись из графика?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        IsBusy = true;
        try
        {
            if (await _apiService.DeleteWorkScheduleAsync(ws.ScheduleId))
                Schedules.Remove(ws);
            else MessageBox.Show("Ошибка удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }
}
