using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using StroyMarket.Models;
using StroyMarket.Services;
using StroyMarket.Windows;

namespace StroyMarket.ViewModels;

public class SalaryViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;
    public bool IsDirector => CurrentUser.Instance.RoleName == "Директор";

    public ObservableCollection<SalaryModel> Salaries { get; } = new();

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                ((RelayCommand)ReloadCommand).RaiseCanExecuteChanged();
                ((RelayCommand)AddCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public ICommand ReloadCommand { get; }
    public ICommand AddCommand { get; }
    public ICommand EditCommand { get; }
    public ICommand DeleteCommand { get; }

    public SalaryViewModel()
    {
        CurrentUser.Changed += OnCurrentUserChanged;

        ReloadCommand = new RelayCommand(async _ => await LoadAsync(), _ => !IsBusy);
        AddCommand = new RelayCommand(async p => await AddAsync(), _ => !IsBusy);
        EditCommand = new RelayCommand(async p => await EditAsync(p as SalaryModel), p => !IsBusy && p is SalaryModel);
        DeleteCommand = new RelayCommand(async p => await DeleteAsync(p as SalaryModel), p => !IsBusy && p is SalaryModel);
        _ = LoadAsync();
    }

    private void OnCurrentUserChanged()
    {
        OnPropertyChanged(nameof(FullName));
        OnPropertyChanged(nameof(RoleName));
        OnPropertyChanged(nameof(IsDirector));
    }

    private async Task LoadAsync()
    {
        IsBusy = true;
        try
        {
            Salaries.Clear();
            int? filterByEmployee = IsDirector ? null : CurrentUser.Instance.UserId;
            var items = await _apiService.GetSalariesAsync(filterByEmployee);
            if (items != null)
            {
                foreach (var s in items)
                {
                    Salaries.Add(s);
                }
            }
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка загрузки зарплат: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task AddAsync()
    {
        var firstDayOfMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        var model = new SalaryModel
        {
            SalaryId = 0,
            EmployeeId = 0,
            EmployeeName = string.Empty,
            BaseAmount = 0,
            Bonus = 0,
            Penalty = 0,
            Period = firstDayOfMonth
        };

        var dialog = new SalaryEditDialog(model);
        if (dialog.ShowDialog() != true)
            return;

        IsBusy = true;
        try
        {
            var created = await _apiService.CreateSalaryAsync(model);
            if (created == null)
            {
                MessageBox.Show("Не удалось создать запись о зарплате.\n" + _apiService.GetLastError(), "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Salaries.Insert(0, created);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task EditAsync(SalaryModel? salary)
    {
        if (salary == null) return;

        var copy = new SalaryModel
        {
            SalaryId = salary.SalaryId,
            EmployeeId = salary.EmployeeId,
            EmployeeName = salary.EmployeeName,
            BaseAmount = salary.BaseAmount,
            Bonus = salary.Bonus,
            Penalty = salary.Penalty,
            Period = salary.Period
        };

        var dialog = new SalaryEditDialog(copy);
        if (dialog.ShowDialog() != true)
            return;

        IsBusy = true;
        try
        {
            var ok = await _apiService.UpdateSalaryAsync(copy);
            if (!ok)
            {
                MessageBox.Show("Не удалось сохранить изменения.\n" + _apiService.GetLastError(), "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            await LoadAsync();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task DeleteAsync(SalaryModel? salary)
    {
        if (salary == null) return;
        if (MessageBox.Show($"Удалить запись о зарплате за {salary.Period:yyyy-MM}?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        IsBusy = true;
        try
        {
            var ok = await _apiService.DeleteSalaryAsync(salary.SalaryId);
            if (!ok)
            {
                MessageBox.Show("Не удалось удалить запись.\n" + _apiService.GetLastError(), "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Salaries.Remove(salary);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }
}

