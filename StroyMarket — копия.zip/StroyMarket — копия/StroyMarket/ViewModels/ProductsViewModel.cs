using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using StroyMarket.Models;
using StroyMarket.Services;
using StroyMarket.Windows;

namespace StroyMarket.ViewModels;

public class ProductsViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();
    private DispatcherTimer? _searchDebounceTimer;

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;

    public ObservableCollection<ProductModel> Products { get; } = new();
    public ObservableCollection<CategoryModel> Categories { get; } = new();

    private string _searchText = "";
    public string SearchText
    {
        get => _searchText;
        set
        {
            if (!SetProperty(ref _searchText, value ?? ""))
                return;
            ScheduleSearchDebounce();
        }
    }

    private int? _selectedCategoryId = 0;
    public int? SelectedCategoryId
    {
        get => _selectedCategoryId;
        set
        {
            if (!SetProperty(ref _selectedCategoryId, value))
                return;
            _ = LoadAsync();
        }
    }

    private string? _selectedStatus = "активен";
    public string? SelectedStatus
    {
        get => _selectedStatus;
        set
        {
            if (!SetProperty(ref _selectedStatus, value))
                return;
            _ = LoadAsync();
        }
    }

    public string[] StatusFilterOptions { get; } = { "Все статусы", "активен", "неактивен" };

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                ((RelayCommand)ReloadCommand).RaiseCanExecuteChanged();
                ((RelayCommand)AddCommand).RaiseCanExecuteChanged();
                ((RelayCommand)EditCommand).RaiseCanExecuteChanged();
                ((RelayCommand)DeleteCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public ICommand ReloadCommand { get; }
    public ICommand AddCommand { get; }
    public ICommand EditCommand { get; }
    public ICommand DeleteCommand { get; }

    public ProductsViewModel()
    {
        CurrentUser.Changed += OnCurrentUserChanged;

        ReloadCommand = new RelayCommand(async _ => await LoadAsync(), _ => !IsBusy);
        AddCommand = new RelayCommand(async _ => await AddAsync(), _ => !IsBusy);
        EditCommand = new RelayCommand(async p => await EditAsync(p as ProductModel), p => !IsBusy && p is ProductModel);
        DeleteCommand = new RelayCommand(async p => await DeleteAsync(p as ProductModel), p => !IsBusy && p is ProductModel);
        _ = LoadAsync();
    }

    private void ScheduleSearchDebounce()
    {
        _searchDebounceTimer?.Stop();
        _searchDebounceTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(400)
        };
        _searchDebounceTimer.Tick += (_, _) =>
        {
            _searchDebounceTimer?.Stop();
            _searchDebounceTimer = null;
            _ = LoadAsync();
        };
        _searchDebounceTimer.Start();
    }

    private void OnCurrentUserChanged()
    {
        OnPropertyChanged(nameof(FullName));
        OnPropertyChanged(nameof(RoleName));
    }

    private async Task LoadAsync()
    {
        IsBusy = true;
        try
        {
            Products.Clear();
            if (Categories.Count == 0)
            {
                var cats = await _apiService.GetCategoriesAsync();
                if (cats != null)
                {
                    Categories.Add(new CategoryModel { CategoryId = 0, Name = "Все категории" });
                    foreach (var c in cats)
                        Categories.Add(c);
                }
            }

            var search = string.IsNullOrWhiteSpace(SearchText) ? null : SearchText.Trim();
            var catId = SelectedCategoryId == 0 ? null : SelectedCategoryId;
            var status = (SelectedStatus == "Все статусы" || string.IsNullOrWhiteSpace(SelectedStatus)) ? null : SelectedStatus;

            var items = await _apiService.GetProductsAsync(search, catId, status);
            if (items != null)
            {
                foreach (var p in items)
                {
                    Products.Add(p);
                }
            }
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка загрузки товаров: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task AddAsync()
    {
        var editor = new ProductEditDialog(new ProductModel
        {
            Status = "активен"
        });

        if (editor.ShowDialog() != true)
            return;

        IsBusy = true;
        try
        {
            var created = await _apiService.CreateProductAsync(editor.Model);
            if (created == null)
            {
                MessageBox.Show("Не удалось создать товар.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Products.Add(created);
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка создания товара: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task EditAsync(ProductModel? target)
    {
        if (target == null)
            return;

        var copy = new ProductModel
        {
            ProductId = target.ProductId,
            Name = target.Name,
            Description = target.Description,
            Price = target.Price,
            Quantity = target.Quantity,
            Status = target.Status,
            CategoryId = target.CategoryId,
            CategoryName = target.CategoryName,
            ImagePath = target.ImagePath
        };

        var editor = new ProductEditDialog(copy);
        if (editor.ShowDialog() != true)
            return;

        IsBusy = true;
        try
        {
            var ok = await _apiService.UpdateProductAsync(editor.Model);
            if (!ok)
            {
                MessageBox.Show("Не удалось сохранить изменения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Перезагружаем список товаров, чтобы сразу увидеть изменения
            await LoadAsync();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка сохранения товара: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task DeleteAsync(ProductModel? target)
    {
        if (target == null)
            return;

        if (MessageBox.Show($"Удалить товар \"{target.Name}\"?",
                "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
        {
            return;
        }

        IsBusy = true;
        try
        {
            var ok = await _apiService.DeleteProductAsync(target.ProductId);
            if (!ok)
            {
                MessageBox.Show("Не удалось удалить товар.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Products.Remove(target);
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка удаления товара: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }
}

