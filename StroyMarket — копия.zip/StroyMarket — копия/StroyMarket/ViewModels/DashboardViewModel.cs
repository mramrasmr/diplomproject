using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using StroyMarket.Models;
using StroyMarket.Services;

namespace StroyMarket.ViewModels;

public class DashboardViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;

    private decimal _totalRevenue;
    public decimal TotalRevenue
    {
        get => _totalRevenue;
        set => SetProperty(ref _totalRevenue, value);
    }

    private int _productsInStock;
    public int ProductsInStock
    {
        get => _productsInStock;
        set => SetProperty(ref _productsInStock, value);
    }

    private int _staffCount;
    public int StaffCount
    {
        get => _staffCount;
        set => SetProperty(ref _staffCount, value);
    }

    private int _ordersToday;
    public int OrdersToday
    {
        get => _ordersToday;
        set => SetProperty(ref _ordersToday, value);
    }

    public ObservableCollection<LowStockProductModel> LowStockProducts { get; } = new();

    public DashboardViewModel()
    {
        CurrentUser.Changed += OnCurrentUserChanged;
        _ = LoadAsync();
    }

    private void OnCurrentUserChanged()
    {
        OnPropertyChanged(nameof(FullName));
        OnPropertyChanged(nameof(RoleName));
    }

    private async Task LoadAsync()
    {
        try
        {
            var summary = await _apiService.GetDashboardSummaryAsync();
            if (summary == null) return;

            TotalRevenue = summary.TotalRevenue;
            ProductsInStock = summary.ProductsInStock;
            StaffCount = summary.StaffCount;
            OrdersToday = summary.OrdersToday;

            LowStockProducts.Clear();
            foreach (var p in summary.LowStockProducts)
            {
                LowStockProducts.Add(p);
            }
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка загрузки дашборда: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}

