using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using StroyMarket.Models;
using StroyMarket.Services;

namespace StroyMarket.ViewModels;

public class EmployeeScheduleViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;

    public ObservableCollection<WorkScheduleModel> Schedules { get; } = new();

    private DateTime _filterFrom = DateTime.Today;
    public DateTime FilterFrom
    {
        get => _filterFrom;
        set
        {
            var v = value.Date;
            if (v > _filterTo.Date) SetProperty(ref _filterTo, v);
            if (SetProperty(ref _filterFrom, v)) _ = LoadAsync();
        }
    }

    private DateTime _filterTo = DateTime.Today.AddDays(7);
    public DateTime FilterTo
    {
        get => _filterTo;
        set
        {
            var v = value.Date;
            if (v < _filterFrom.Date) SetProperty(ref _filterFrom, v);
            if (SetProperty(ref _filterTo, v)) _ = LoadAsync();
        }
    }

    public EmployeeScheduleViewModel()
    {
        CurrentUser.Changed += () =>
        {
            OnPropertyChanged(nameof(FullName));
            OnPropertyChanged(nameof(RoleName));
        };
        _ = LoadAsync();
    }

    private async Task LoadAsync()
    {
        Schedules.Clear();
        var items = await _apiService.GetWorkSchedulesAsync(
            CurrentUser.Instance.UserId, FilterFrom, FilterTo);
        if (items != null)
            foreach (var ws in items)
                Schedules.Add(ws);
    }
}
