using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using StroyMarket.Models;
using StroyMarket.Services;

namespace StroyMarket.ViewModels;

public class OrdersViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;

    public ObservableCollection<OrderModel> Orders { get; } = new();

    private OrderModel? _selectedOrder;
    public OrderModel? SelectedOrder
    {
        get => _selectedOrder;
        set
        {
            if (SetProperty(ref _selectedOrder, value))
            {
                _newStatusForSelected = value?.Status;
                OnPropertyChanged(nameof(NewStatusForSelected));
                ((RelayCommand)UpdateStatusCommand).RaiseCanExecuteChanged();
                ((RelayCommand)ArchiveCommand).RaiseCanExecuteChanged();
                ((RelayCommand)UnarchiveCommand).RaiseCanExecuteChanged();
            }
        }
    }

    private bool _showArchived;
    public bool ShowArchived
    {
        get => _showArchived;
        set
        {
            if (SetProperty(ref _showArchived, value))
                _ = LoadAsync();
        }
    }

    private string? _newStatusForSelected;
    public string? NewStatusForSelected
    {
        get => _newStatusForSelected ?? SelectedOrder?.Status;
        set
        {
            if (SetProperty(ref _newStatusForSelected, value))
                ((RelayCommand)UpdateStatusCommand).RaiseCanExecuteChanged();
        }
    }

    private string? _selectedStatusFilter = "Все статусы";
    public string? SelectedStatusFilter
    {
        get => _selectedStatusFilter;
        set
        {
            if (SetProperty(ref _selectedStatusFilter, value))
                _ = LoadAsync();
        }
    }

    public string[] StatusFilterOptions { get; } =
    {
        "Все статусы", "создан", "принят", "собирается", "готов", "едет к вам", "отменен"
    };

    public string[] StatusOptions { get; } =
    {
        "создан", "принят", "собирается", "готов", "едет к вам", "отменен"
    };

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                ((RelayCommand)ReloadCommand).RaiseCanExecuteChanged();
                ((RelayCommand)UpdateStatusCommand).RaiseCanExecuteChanged();
                ((RelayCommand)ArchiveCommand).RaiseCanExecuteChanged();
                ((RelayCommand)UnarchiveCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public ICommand ReloadCommand { get; }
    public ICommand UpdateStatusCommand { get; }
    public ICommand ArchiveCommand { get; }
    public ICommand UnarchiveCommand { get; }

    public OrdersViewModel()
    {
        CurrentUser.Changed += () =>
        {
            OnPropertyChanged(nameof(FullName));
            OnPropertyChanged(nameof(RoleName));
        };

        ReloadCommand = new RelayCommand(async _ => await LoadAsync(), _ => !IsBusy);
        UpdateStatusCommand = new RelayCommand(async _ => await UpdateStatusAsync(NewStatusForSelected), _ => !IsBusy && SelectedOrder != null && !string.IsNullOrWhiteSpace(NewStatusForSelected));
        ArchiveCommand = new RelayCommand(async _ => await ArchiveSelectedAsync(), _ => !IsBusy && SelectedOrder != null && !SelectedOrder.IsArchived);
        UnarchiveCommand = new RelayCommand(async _ => await UnarchiveSelectedAsync(), _ => !IsBusy && SelectedOrder != null && SelectedOrder.IsArchived);
        _ = LoadAsync();
    }

    private async Task LoadAsync()
    {
        IsBusy = true;
        try
        {
            Orders.Clear();
            var status = (SelectedStatusFilter == "Все статусы" || string.IsNullOrWhiteSpace(SelectedStatusFilter)) ? null : SelectedStatusFilter;
            var items = await _apiService.GetOrdersAsync(status, ShowArchived);
            if (items != null)
            {
                foreach (var o in items)
                    Orders.Add(o);
            }
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    public async Task UpdateStatusAsync(string? status)
    {
        if (string.IsNullOrWhiteSpace(status) || SelectedOrder == null)
            return;

        IsBusy = true;
        try
        {
            var ok = await _apiService.UpdateOrderStatusAsync(SelectedOrder.OrderId, status);
            if (!ok)
            {
                MessageBox.Show("Не удалось обновить статус.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            SelectedOrder.Status = status;
            var orderId = SelectedOrder.OrderId;
            await LoadAsync();
            SelectedOrder = Orders.FirstOrDefault(o => o.OrderId == orderId);
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task ArchiveSelectedAsync()
    {
        if (SelectedOrder == null || SelectedOrder.IsArchived)
            return;

        if (MessageBox.Show($"Архивировать заказ #{SelectedOrder.OrderId}?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        IsBusy = true;
        try
        {
            var ok = await _apiService.ArchiveOrderAsync(SelectedOrder.OrderId);
            if (!ok)
            {
                MessageBox.Show("Не удалось архивировать заказ.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Orders.Remove(SelectedOrder);
            SelectedOrder = null;
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task UnarchiveSelectedAsync()
    {
        if (SelectedOrder == null || !SelectedOrder.IsArchived)
            return;

        if (MessageBox.Show($"Вернуть заказ #{SelectedOrder.OrderId} из архива?", "Подтверждение",
                MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;

        IsBusy = true;
        try
        {
            var ok = await _apiService.UnarchiveOrderAsync(SelectedOrder.OrderId);
            if (!ok)
            {
                MessageBox.Show("Не удалось вернуть заказ из архива.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Orders.Remove(SelectedOrder);
            SelectedOrder = null;
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }
}
