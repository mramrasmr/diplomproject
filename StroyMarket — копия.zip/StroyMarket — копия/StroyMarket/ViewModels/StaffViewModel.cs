using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using StroyMarket.Models;
using StroyMarket.Services;
using StroyMarket.Windows;

namespace StroyMarket.ViewModels;

public class StaffViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();
    private DispatcherTimer? _searchDebounceTimer;

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;

    /// <summary>true — роль «Директор», показываем кнопки добавления/редактирования/удаления.</summary>
    public bool IsDirector => CurrentUser.Instance.RoleName == "Директор";

    public ObservableCollection<StaffModel> Staff { get; } = new();
    public ObservableCollection<RoleFilterItem> RoleFilters { get; } = new();

    private string _searchText = "";
    public string SearchText
    {
        get => _searchText;
        set
        {
            if (!SetProperty(ref _searchText, value ?? ""))
                return;
            ScheduleSearchDebounce();
        }
    }

    private int? _selectedRoleId = 0;
    public int? SelectedRoleId
    {
        get => _selectedRoleId;
        set
        {
            if (!SetProperty(ref _selectedRoleId, value))
                return;
            _ = LoadAsync();
        }
    }

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                ((RelayCommand)ReloadCommand).RaiseCanExecuteChanged();
                ((RelayCommand)AddCommand).RaiseCanExecuteChanged();
                ((RelayCommand)EditCommand).RaiseCanExecuteChanged();
                ((RelayCommand)DeleteCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public ICommand ReloadCommand { get; }
    public ICommand AddCommand { get; }
    public ICommand EditCommand { get; }
    public ICommand DeleteCommand { get; }

    public StaffViewModel()
    {
        CurrentUser.Changed += OnCurrentUserChanged;

        ReloadCommand = new RelayCommand(async _ => await LoadAsync(), _ => !IsBusy);
        AddCommand = new RelayCommand(async _ => await AddAsync(), _ => !IsBusy);
        EditCommand = new RelayCommand(async p => await EditAsync(p as StaffModel), p => !IsBusy && p is StaffModel);
        DeleteCommand = new RelayCommand(async p => await DeleteAsync(p as StaffModel), p => !IsBusy && p is StaffModel);
        _ = LoadAsync();
    }

    private void ScheduleSearchDebounce()
    {
        _searchDebounceTimer?.Stop();
        _searchDebounceTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(400)
        };
        _searchDebounceTimer.Tick += (_, _) =>
        {
            _searchDebounceTimer?.Stop();
            _searchDebounceTimer = null;
            _ = LoadAsync();
        };
        _searchDebounceTimer.Start();
    }

    private void OnCurrentUserChanged()
    {
        OnPropertyChanged(nameof(FullName));
        OnPropertyChanged(nameof(RoleName));
    }

    private async Task LoadAsync()
    {
        IsBusy = true;
        try
        {
            Staff.Clear();
            if (RoleFilters.Count == 0)
            {
                var roles = await _apiService.GetRolesAsync();
                if (roles != null)
                {
                    RoleFilters.Add(new RoleFilterItem(0, "Все роли"));
                    foreach (var r in roles)
                        RoleFilters.Add(new RoleFilterItem(r.RoleId, r.RoleName));
                }
            }

            var search = string.IsNullOrWhiteSpace(SearchText) ? null : SearchText.Trim();
            var roleId = SelectedRoleId == 0 ? null : SelectedRoleId;

            var items = await _apiService.GetStaffAsync(search, roleId);
            if (items != null)
            {
                foreach (var s in items)
                {
                    Staff.Add(s);
                }
            }
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка загрузки сотрудников: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task AddAsync()
    {
        var model = new StaffEditModel
        {
            RoleId = 2,
            RoleName = "Сотрудник"
        };

        var dialog = new StaffEditDialog(model);
        if (dialog.ShowDialog() != true)
            return;

        IsBusy = true;
        try
        {
            var created = await _apiService.CreateStaffAsync(model);
            if (created == null)
            {
                MessageBox.Show("Не удалось создать сотрудника.\n" + _apiService.GetLastError(), "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Staff.Add(created);
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка создания сотрудника: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task EditAsync(StaffModel? staff)
    {
        if (staff == null)
            return;

        var model = new StaffEditModel
        {
            UserId = staff.UserId,
            FullName = staff.FullName,
            RoleName = staff.RoleName,
            RoleId = staff.RoleId,
            Login = staff.Login,
            Email = staff.Email,
            Phone = staff.Phone,
            // роль и логин нужно будет заполнить вручную при редактировании
        };

        var dialog = new StaffEditDialog(model);
        if (dialog.ShowDialog() != true)
            return;

        IsBusy = true;
        try
        {
            var ok = await _apiService.UpdateStaffAsync(model);
            if (!ok)
            {
                MessageBox.Show("Не удалось сохранить изменения сотрудника.\n" + _apiService.GetLastError(), "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Если изменили текущего пользователя — обновим данные профиля в CurrentUser,
            // чтобы окно профиля и шапка показывали актуальные ФИО и роль.
            if (staff.UserId == CurrentUser.Instance.UserId)
            {
                CurrentUser.Instance.FullName = model.FullName;
                CurrentUser.Instance.RoleName = model.RoleId switch
                {
                    3 => "Директор",
                    2 => "Сотрудник",
                    _ => CurrentUser.Instance.RoleName
                };
            }

            await LoadAsync();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка сохранения сотрудника: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task DeleteAsync(StaffModel? staff)
    {
        if (staff == null)
            return;

        if (MessageBox.Show($"Удалить сотрудника \"{staff.FullName}\"?",
                "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
        {
            return;
        }

        IsBusy = true;
        try
        {
            var ok = await _apiService.DeleteStaffAsync(staff.UserId);
            if (!ok)
            {
                MessageBox.Show("Не удалось удалить сотрудника.\n" + _apiService.GetLastError(), "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Staff.Remove(staff);
        }
        catch (System.Exception ex)
        {
            MessageBox.Show($"Ошибка удаления сотрудника: {ex.Message}", "Ошибка",
                MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }
}

public class RoleFilterItem
{
    public int RoleId { get; set; }
    public string RoleName { get; set; } = string.Empty;
    public RoleFilterItem() { }
    public RoleFilterItem(int id, string name) { RoleId = id; RoleName = name; }
}

