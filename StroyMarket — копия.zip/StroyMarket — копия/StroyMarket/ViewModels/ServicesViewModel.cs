using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using StroyMarket.Models;
using StroyMarket.Services;
using StroyMarket.Windows;

namespace StroyMarket.ViewModels;

public class ServicesViewModel : BaseViewModel
{
    private readonly ApiService _apiService = new();

    public string FullName => CurrentUser.Instance.FullName;
    public string RoleName => CurrentUser.Instance.RoleName;

    public ObservableCollection<ServiceModel> Services { get; } = new();
    public ObservableCollection<CategoryModel> CategoryOptions { get; } = new();

    private int? _selectedCategoryId = 0;
    public int? SelectedCategoryId
    {
        get => _selectedCategoryId;
        set
        {
            if (SetProperty(ref _selectedCategoryId, value))
                _ = LoadAsync();
        }
    }

    private ServiceModel? _selectedService;
    public ServiceModel? SelectedService
    {
        get => _selectedService;
        set => SetProperty(ref _selectedService, value);
    }

    private bool _isBusy;
    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (SetProperty(ref _isBusy, value))
            {
                ((RelayCommand)ReloadCommand).RaiseCanExecuteChanged();
                ((RelayCommand)AddCommand).RaiseCanExecuteChanged();
                ((RelayCommand)EditCommand).RaiseCanExecuteChanged();
                ((RelayCommand)DeleteCommand).RaiseCanExecuteChanged();
            }
        }
    }

    public ICommand ReloadCommand { get; }
    public ICommand AddCommand { get; }
    public ICommand EditCommand { get; }
    public ICommand DeleteCommand { get; }

    public ServicesViewModel()
    {
        CurrentUser.Changed += () => { OnPropertyChanged(nameof(FullName)); OnPropertyChanged(nameof(RoleName)); };
        ReloadCommand = new RelayCommand(async _ => await LoadAsync(), _ => !IsBusy);
        AddCommand = new RelayCommand(async _ => await AddAsync(), _ => !IsBusy);
        EditCommand = new RelayCommand(async p => await EditAsync(p as ServiceModel), p => !IsBusy && p is ServiceModel);
        DeleteCommand = new RelayCommand(async p => await DeleteAsync(p as ServiceModel), p => !IsBusy && p is ServiceModel);
        _ = LoadAsync();
    }

    private async Task LoadAsync()
    {
        IsBusy = true;
        try
        {
            if (CategoryOptions.Count == 0)
            {
                var cats = await _apiService.GetCategoriesAsync();
                if (cats != null)
                {
                    CategoryOptions.Add(new CategoryModel { CategoryId = 0, Name = "Все категории" });
                    foreach (var c in cats)
                        CategoryOptions.Add(c);
                }
            }

            Services.Clear();
            var categoryId = SelectedCategoryId == 0 ? null : SelectedCategoryId;
            var items = await _apiService.GetServicesAsync(categoryId);
            if (items != null) foreach (var s in items) Services.Add(s);
        }
        finally { IsBusy = false; }
    }

    private async Task AddAsync()
    {
        var dlg = new ServiceEditDialog(new ServiceModel(), CategoryOptions.Where(c => c.CategoryId != 0).ToList());
        if (dlg.ShowDialog() != true) return;
        IsBusy = true;
        try
        {
            if (await _apiService.CreateServiceAsync(dlg.Model))
                await LoadAsync();
            else MessageBox.Show("Ошибка создания услуги.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    private async Task EditAsync(ServiceModel? s)
    {
        if (s == null) return;
        var copy = new ServiceModel { ServiceId = s.ServiceId, Name = s.Name, Description = s.Description, Price = s.Price, CategoryId = s.CategoryId, CategoryName = s.CategoryName };
        var dlg = new ServiceEditDialog(copy, CategoryOptions.Where(c => c.CategoryId != 0).ToList());
        if (dlg.ShowDialog() != true) return;
        IsBusy = true;
        try
        {
            if (await _apiService.UpdateServiceAsync(dlg.Model))
                await LoadAsync();
            else MessageBox.Show("Ошибка сохранения.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }

    private async Task DeleteAsync(ServiceModel? s)
    {
        if (s == null) return;
        if (MessageBox.Show($"Удалить услугу \"{s.Name}\"?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
        IsBusy = true;
        try
        {
            if (await _apiService.DeleteServiceAsync(s.ServiceId))
                Services.Remove(s);
            else MessageBox.Show("Ошибка удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { IsBusy = false; }
    }
}
