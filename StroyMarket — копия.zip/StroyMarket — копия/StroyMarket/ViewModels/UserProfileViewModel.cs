using StroyMarket.Models;

namespace StroyMarket.ViewModels;

public class UserProfileViewModel : BaseViewModel
{
    private string _fullName = string.Empty;
    public string FullName
    {
        get => _fullName;
        set => SetProperty(ref _fullName, value);
    }

    private string _roleName = string.Empty;
    public string RoleName
    {
        get => _roleName;
        set => SetProperty(ref _roleName, value);
    }

    private int _userId;
    public int UserId
    {
        get => _userId;
        set => SetProperty(ref _userId, value);
    }

    private string _token = string.Empty;
    public string Token
    {
        get => _token;
        set => SetProperty(ref _token, value);
    }

    public UserProfileViewModel()
    {
        var u = CurrentUser.Instance;
        UserId = u.UserId;
        FullName = u.FullName;
        RoleName = u.RoleName;
        Token = u.Token;
    }
}

